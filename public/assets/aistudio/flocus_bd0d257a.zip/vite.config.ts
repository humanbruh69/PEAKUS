import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import crypto from 'node:crypto';

// In-memory or Redis-backed sync handler for /api/sync
const memoryDoc = { doc: null as any };

export default defineConfig({
  plugins: [
    react(),
    tailwindcss(),
    {
      name: 'api-sync-handler',
      configureServer(server) {
        server.middlewares.use(async (req, res, next) => {
          if (!req.url?.startsWith('/api/sync')) {
            return next();
          }

          res.setHeader('Content-Type', 'application/json; charset=utf-8');
          res.setHeader('Cache-Control', 'no-store');

          const syncKey = process.env.SYNC_KEY || '';
          const hasDb = !!(
            (process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL) &&
            (process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN)
          );

          // If not configured with database or key
          if (!hasDb || syncKey.length < 12) {
            res.statusCode = 503;
            res.end(JSON.stringify({ error: 'not_configured', db: hasDb, key: syncKey.length >= 12 }));
            return;
          }

          const givenKey = req.headers['x-sync-key'];
          const a = crypto.createHash('sha256').update(String(givenKey || '')).digest();
          const b = crypto.createHash('sha256').update(String(syncKey)).digest();
          if (!crypto.timingSafeEqual(a, b)) {
            res.statusCode = 401;
            res.end(JSON.stringify({ error: 'bad_key' }));
            return;
          }

          if (req.method === 'GET') {
            res.statusCode = 200;
            res.end(JSON.stringify({ doc: memoryDoc.doc, serverTime: Date.now() }));
            return;
          }

          if (req.method === 'POST') {
            const chunks: Buffer[] = [];
            for await (const chunk of req) {
              chunks.push(chunk as Buffer);
            }
            try {
              const body = JSON.parse(Buffer.concat(chunks).toString('utf8'));
              memoryDoc.doc = body.doc;
              res.statusCode = 200;
              res.end(JSON.stringify({ doc: body.doc, serverTime: Date.now() }));
            } catch {
              res.statusCode = 400;
              res.end(JSON.stringify({ error: 'bad_doc' }));
            }
            return;
          }

          res.statusCode = 405;
          res.end(JSON.stringify({ error: 'method' }));
        });
      },
    },
  ],
  server: {
    host: '0.0.0.0',
    port: 3000,
  },
});
