// Sincronización de foco: guarda un único documento JSON en Upstash Redis.
// Variables de entorno:
//   SYNC_KEY                         clave que escribís en cada dispositivo (mínimo 12 caracteres)
//   KV_REST_API_URL / KV_REST_API_TOKEN            (las crea la integración de Upstash en Vercel)
//   o UPSTASH_REDIS_REST_URL / UPSTASH_REDIS_REST_TOKEN
import crypto from 'node:crypto';
import FocoMerge from '../lib/merge.js';

const KEY = 'foco:doc:v1';
const MAX_BYTES = 3 * 1024 * 1024;

function send(res, status, body) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.end(JSON.stringify(body));
}

function sameKey(given, expected) {
  const a = crypto.createHash('sha256').update(String(given || '')).digest();
  const b = crypto.createHash('sha256').update(String(expected || '')).digest();
  return crypto.timingSafeEqual(a, b);
}

async function redis(cmd) {
  const url = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL;
  const token = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN;
  const r = await fetch(url, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify(cmd) });
  const j = await r.json().catch(() => ({}));
  if (!r.ok || j.error) throw new Error(j.error || `redis ${r.status}`);
  return j.result;
}

async function readBody(req) {
  if (req.body !== undefined) return typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
  const chunks = []; let size = 0;
  for await (const c of req) { size += c.length; if (size > MAX_BYTES) throw Object.assign(new Error('too_large'), { status: 413 }); chunks.push(c); }
  return chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {};
}

export default async function handler(req, res) {
  const hasDb = !!((process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL) && (process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN));
  const syncKey = process.env.SYNC_KEY || '';
  if (!hasDb || syncKey.length < 12) return send(res, 503, { error: 'not_configured', db: hasDb, key: syncKey.length >= 12 });
  if (!sameKey(req.headers['x-sync-key'], syncKey)) return send(res, 401, { error: 'bad_key' });
  try {
    const raw = await redis(['GET', KEY]);
    const stored = raw ? JSON.parse(raw) : null;
    if (req.method === 'GET') return send(res, 200, { doc: stored, serverTime: Date.now() });
    if (req.method !== 'POST') return send(res, 405, { error: 'method' });
    const body = await readBody(req);
    if (!FocoMerge.validDoc(body.doc)) return send(res, 400, { error: 'bad_doc' });
    const merged = FocoMerge.mergeDocs(stored || {}, body.doc);
    const out = JSON.stringify(merged);
    if (out.length > MAX_BYTES) return send(res, 413, { error: 'too_large' });
    if (out !== raw) await redis(['SET', KEY, out]);
    return send(res, 200, { doc: merged, serverTime: Date.now() });
  } catch (e) {
    if (e.status) return send(res, e.status, { error: e.message });
    console.error(e);
    return send(res, 502, { error: 'storage', message: String(e.message || e).slice(0, 200) });
  }
}
