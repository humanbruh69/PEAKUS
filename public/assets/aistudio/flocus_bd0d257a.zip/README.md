# foco — publicación en Vercel con datos en la nube

Qué hay acá:
- `index.html`: la app completa.
- `api/sync.js`: función que guarda tus datos en Upstash (Redis), protegida con tu clave.
- `lib/merge.js`: combina los cambios de varios dispositivos sin duplicar ni perder nada.
- `manifest.webmanifest`, `sw.js` e íconos: permiten instalarla como app y abrirla sin conexión.

## 1. Subir el proyecto a Vercel

**Opción sin terminal (GitHub):**
1. En github.com, creá un repositorio nuevo (puede ser privado), por ejemplo `foco`.
2. Tocá *uploading an existing file* y arrastrá **todo el contenido de esta carpeta**, incluidas las carpetas `api` y `lib`. Confirmá con *Commit changes*.
3. En vercel.com, entrá con tu cuenta de GitHub → *Add New… → Project* → importá el repo `foco`.
4. Dejá *Framework Preset* en **Other** y tocá **Deploy**.

**Opción con terminal:** en esta carpeta, ejecutá `npx vercel` y seguí las preguntas. Después, `npx vercel --prod`.

## 2. Crear la base de datos (gratis)
1. En el proyecto de Vercel: pestaña **Storage** → *Create Database* → **Upstash for Redis** → plan **Free**.
2. Conectala al proyecto. Vercel crea solo las variables `KV_REST_API_URL` y `KV_REST_API_TOKEN`.

## 3. Definir tu clave
1. Abrí tu app → Ajustes → Datos → **Generar una segura**, y copiá la clave.
2. En Vercel: **Settings → Environment Variables** → nombre `SYNC_KEY`, valor: esa clave.
3. **Deployments** → en el último, menú ⋯ → **Redeploy**, para que tome las variables.

## 4. Conectar cada dispositivo
Ajustes → Datos → pegá la clave → **Conectar**. Repetilo en la compu y en el celular.
- Tareas e historial se combinan con lo que ya hubiera en la nube.
- Si la nube ya tenía datos, se usan sus ajustes y notas.
- El modo (Home, Focus o Ambient) y las imágenes propias quedan por dispositivo.

## En el celular
Abrí tu dirección `.vercel.app` en Safari → botón Compartir → **Agregar a pantalla de inicio**. En Android con Chrome: menú ⋮ → **Instalar app**.

## Pasar tus datos de la versión anterior
En la versión vieja: Ajustes → Datos → **Exportar JSON**. En la nueva, antes de conectar: **Importar JSON**. Después conectá la sincronización.

## Sobre los datos
- Upstash gratis: 256 MB y 500.000 operaciones por mes. Esta app usa unas pocas miles por mes.
- Si pasan más de 30 días sin ningún uso, Upstash archiva la base: avisa por mail y guarda un respaldo que se restaura desde su consola.
- Cada dispositivo conectado guarda una copia completa y la vuelve a subir si hace falta.
- La clave protege tus datos: no la compartas. Si la cambiás en Vercel, reconectá cada dispositivo.
