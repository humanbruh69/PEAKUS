import React, { useEffect, useState, useRef } from 'react';
import { Icon } from './Icons';
import { Store } from '../lib/store';
import { sync } from '../lib/sync';

interface NotesPopoverProps {
  open: boolean;
  onClose: () => void;
}

export const NotesPopover: React.FC<NotesPopoverProps> = ({ open, onClose }) => {
  const [text, setText] = useState<string>('');
  const saveTimeout = useRef<any>(null);

  useEffect(() => {
    if (open) {
      const doc = Store.loadNotesDoc();
      setText(doc.text);
    }
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [open, onClose]);

  const handleChange = (val: string) => {
    setText(val);
    clearTimeout(saveTimeout.current);
    saveTimeout.current = setTimeout(() => {
      Store.saveNotes(val, Date.now());
      sync.touch();
    }, 400);
  };

  if (!open) return null;

  return (
    <div className="pop" role="dialog" aria-label="Notas rápidas">
      <div className="pop-head">
        <span className="badge-ic" aria-hidden="true">
          <Icon name="pencil" />
        </span>
        <h2>Notas rápidas</h2>
        <button
          className="x-btn"
          aria-label="Cerrar notas rápidas"
          onClick={onClose}
        >
          <Icon name="x" />
        </button>
      </div>

      <div className="pop-body">
        <textarea
          id="notesTa"
          value={text}
          placeholder="Anotá lo que tengas en la cabeza para no perder el foco..."
          rows={10}
          autoFocus
          onChange={e => handleChange(e.target.value)}
        />
      </div>
    </div>
  );
};
