import React, { useState, useEffect, useRef } from 'react';
import { Icon } from './Icons';
import type { Settings, ModeKey, Task, Session } from '../types';
import {
  SCENES,
  SOLIDS,
  CATEGORIES,
  renderScene,
} from '../lib/scenes';
import { DEFAULTS, QUOTES } from '../lib/constants';
import {
  fmtDur,
  fmtClock,
  dayKey,
  startOfDay,
  addDays,
  uid,
  clone,
} from '../lib/utils';
import { imageDB, type CustomImage } from '../lib/imageDB';
import { audioX } from '../lib/audio';
import { sync } from '../lib/sync';
import { Store } from '../lib/store';

interface SettingsModalProps {
  open: boolean;
  onClose: () => void;
  settings: Settings;
  onUpdateSettings: (s: Settings, path?: string) => void;
  tasks: Task[];
  onUpdateTasks: (tasks: Task[]) => void;
  sessions: Session[];
  onUpdateSessions: (sessions: Session[]) => void;
  onToast: (msg: string, type?: '' | 'err') => void;
  onConfirm: (
    title: string,
    text: string,
    okLabel: string,
    fn: () => void,
    danger?: boolean
  ) => void;
}

type SectionKey = 'themes' | 'clock' | 'timer' | 'stats' | 'quotes' | 'extras' | 'data';

const NAV_ITEMS: [SectionKey, string, string][] = [
  ['themes', 'Temas', 'palette'],
  ['clock', 'Reloj', 'clock'],
  ['timer', 'Temporizador', 'timer'],
  ['stats', 'Estadísticas', 'chart'],
  ['quotes', 'Frases', 'quote'],
  ['extras', 'Extras', 'sparkles'],
  ['data', 'Datos', 'data'],
];

const thumbsCache = new Map<string, string>();
function getThumbURL(id: string): string {
  if (thumbsCache.has(id)) return thumbsCache.get(id)!;
  const scene = SCENES.find(s => s.id === id);
  if (!scene) return '';
  const cv = renderScene(scene, 400);
  const url = cv.toDataURL('image/jpeg', 0.82);
  thumbsCache.set(id, url);
  return url;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  open,
  onClose,
  settings,
  onUpdateSettings,
  tasks,
  onUpdateTasks,
  sessions,
  onUpdateSessions,
  onToast,
  onConfirm,
}) => {
  const [section, setSection] = useState<SectionKey>('themes');
  const [editMode, setEditMode] = useState<ModeKey>(settings.mode);
  const [libCat, setLibCat] = useState<string>('all');
  const [seeAll, setSeeAll] = useState<Set<string>>(new Set());
  const [accOpen, setAccOpen] = useState(false);
  const [customUploads, setCustomUploads] = useState<CustomImage[]>([]);

  // Stats tab states
  const [statPeriod, setStatPeriod] = useState<string>('week');
  const [heatMetric, setHeatMetric] = useState<'hours' | 'sessions'>('hours');
  const [heatSpan, setHeatSpan] = useState<'6m' | '1y'>('6m');
  const [histLimit, setHistLimit] = useState<number>(20);

  // Sync tab states
  const [syncKeyInput, setSyncKeyInput] = useState('');
  const [genSyncKey, setGenSyncKey] = useState('');
  const [, setSyncTick] = useState(0);

  useEffect(() => {
    if (!open) return;
    setEditMode(settings.mode);
  }, [open, settings.mode]);

  useEffect(() => {
    return sync.subscribe(() => {
      setSyncTick(t => t + 1);
    });
  }, []);

  useEffect(() => {
    if (accOpen || section === 'themes') {
      imageDB
        .list()
        .then((list: CustomImage[]) => setCustomUploads(list.sort((a, b) => b.createdAt - a.createdAt)))
        .catch(() => {});
    }
  }, [accOpen, section]);

  useEffect(() => {
    if (!open) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [open, onClose]);

  if (!open) return null;

  const currentModeCfg = settings.modes[editMode as keyof typeof settings.modes] || DEFAULTS.modes[editMode as keyof typeof DEFAULTS.modes];

  const updateSettingField = (path: string, val: any) => {
    const keys = path.replace('@', editMode).split('.');
    const nextSettings = clone(settings);
    let o = nextSettings;
    for (let i = 0; i < keys.length - 1; i++) {
      o = (o as any)[keys[i]];
    }
    (o as any)[keys.at(-1)!] = val;
    onUpdateSettings(nextSettings, path.replace('@', editMode));
  };

  const handleFileUpload = async (files: FileList | null) => {
    if (!files || !files.length) return;
    for (const f of Array.from(files)) {
      if (!f.type.startsWith('image/')) {
        onToast(`“${f.name}” no es una imagen.`, 'err');
        continue;
      }
      if (f.size > 25 * 1024 * 1024) {
        onToast(`“${f.name}” pesa más de 25 MB.`, 'err');
        continue;
      }
      const id = uid('img');
      try {
        await imageDB.put({ id, name: f.name.slice(0, 80), blob: f, createdAt: Date.now() });
        updateSettingField(`modes.@.bg`, { kind: 'upload', id });
        onToast(
          `Listo: “${f.name}” quedó como fondo de ${
            ({ home: 'Home', focus: 'Focus', ambient: 'Ambient' } as Record<string, string>)[editMode]
          }.`
        );
      } catch {
        onToast('No se pudo guardar la imagen (almacenamiento lleno o bloqueado).', 'err');
      }
    }
    imageDB.list().then((list: CustomImage[]) => setCustomUploads(list)).catch(() => {});
  };

  const deleteUpload = async (id: string, name: string) => {
    onConfirm(
      '¿Eliminar imagen?',
      `Se eliminará “${name}” del almacenamiento local.`,
      'Eliminar',
      async () => {
        await imageDB.delete(id);
        if (currentModeCfg.bg.kind === 'upload' && currentModeCfg.bg.id === id) {
          updateSettingField(`modes.@.bg`, clone(DEFAULTS.modes[editMode as keyof typeof DEFAULTS.modes].bg));
        }
        setCustomUploads(prev => prev.filter(x => x.id !== id));
      }
    );
  };

  /* ----- Themes Tab Render ----- */
  const renderThemes = () => {
    const bg = currentModeCfg.bg;
    const cats =
      libCat === 'all'
        ? CATEGORIES.slice(1)
        : CATEGORIES.filter((c: [string, string]) => c[0] === libCat);

    const bgDisplayName =
      bg.kind === 'scene'
        ? SCENES.find((s: any) => s.id === bg.id)?.name || 'Fondo'
        : bg.kind === 'color'
        ? (SOLIDS.find((s: [string, string]) => s[0] === bg.color) || [0, 'Color liso'])[1]
        : 'Imagen propia';

    return (
      <div className="content-inner">
        <h1 id="setTitle">Temas</h1>
        <p className="sub-t">Elegí un fondo para cada modo. Los cambios se ven al instante.</p>

        {/* Mode selector */}
        <div style={{ marginBottom: '16px' }}>
          <div className="seg" role="group" aria-label="Modo a editar">
            {(['home', 'focus', 'ambient'] as ModeKey[]).map(m => (
              <button
                key={m}
                aria-pressed={m === editMode}
                onClick={() => setEditMode(m)}
              >
                {({ home: 'Home', focus: 'Focus', ambient: 'Ambient' } as Record<string, string>)[m]}
              </button>
            ))}
          </div>
        </div>

        {/* Preview card */}
        <div
          className="preview-card"
          aria-label={`Vista previa: ${bgDisplayName}`}
          style={{
            backgroundImage:
              bg.kind === 'scene' && bg.id
                ? `url("${getThumbURL(bg.id)}")`
                : bg.kind === 'upload'
                ? undefined
                : 'none',
            backgroundColor: bg.kind === 'color' ? bg.color : undefined,
          }}
        >
          <div className="pv-dim" style={{ opacity: currentModeCfg.dim / 100 }} />
          <div className="pv-clock">
            {editMode === 'focus' ? fmtClock(settings.timer.focus * 60000) : '12:00'}
          </div>
          <div className="pv-name">
            {bgDisplayName}
            {editMode !== settings.mode
              ? ` · modo ${({ home: 'Home', focus: 'Focus', ambient: 'Ambient' } as Record<string, string>)[editMode]}`
              : ''}
          </div>
        </div>

        {/* Custom background accordion */}
        <div className="card">
          <button
            className="accordion-btn"
            aria-expanded={accOpen}
            onClick={() => setAccOpen(!accOpen)}
          >
            Fondo propio <Icon name="chev" />
          </button>
          {accOpen && (
            <div className="acc-body">
              <p className="desc">
                Subí tus imágenes (JPG, PNG, WebP o GIF, hasta 25 MB). Se guardan en este navegador
                y siguen disponibles cuando volvés.
              </p>
              <label className="drop">
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  className="sr-only"
                  onChange={e => handleFileUpload(e.target.files)}
                />
                <Icon name="upload" />
                <br />
                <b style={{ color: 'var(--text)' }}>Elegí una imagen</b> o arrastrala acá
              </label>

              <div className="uploads">
                {customUploads.length === 0 ? (
                  <p className="hint">Todavía no subiste imágenes.</p>
                ) : (
                  customUploads.map(up => (
                    <div key={up.id} className="thumb-wrap">
                      <button
                        className="thumb"
                        aria-pressed={bg.kind === 'upload' && bg.id === up.id}
                        onClick={() =>
                          updateSettingField(`modes.@.bg`, { kind: 'upload', id: up.id })
                        }
                      >
                        <span
                          className="img"
                          style={{
                            backgroundImage: `url("${URL.createObjectURL(up.blob)}")`,
                          }}
                        />
                        <span
                          style={{
                            fontSize: '12.5px',
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            whiteSpace: 'nowrap',
                            maxWidth: '100%',
                          }}
                        >
                          {up.name}
                        </span>
                      </button>
                      <button
                        className="del"
                        aria-label={`Eliminar ${up.name}`}
                        onClick={() => deleteUpload(up.id, up.name)}
                      >
                        <Icon name="trash" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* Adjustments */}
        <div className="card">
          <h3>Ajustes del fondo</h3>
          <p className="desc">Se guardan por modo.</p>

          <div className="slider-row">
            <label>Oscurecer</label>
            <input
              type="range"
              min="0"
              max="90"
              value={currentModeCfg.dim}
              style={{ '--p': `${(currentModeCfg.dim / 90) * 100}%` } as any}
              onChange={e => updateSettingField(`modes.@.dim`, Number(e.target.value))}
            />
            <output>{currentModeCfg.dim}%</output>
          </div>

          <div className="slider-row">
            <label>Desenfocar</label>
            <input
              type="range"
              min="0"
              max="30"
              value={currentModeCfg.blur}
              style={{ '--p': `${(currentModeCfg.blur / 30) * 100}%` } as any}
              onChange={e => updateSettingField(`modes.@.blur`, Number(e.target.value))}
            />
            <output>{currentModeCfg.blur}px</output>
          </div>

          <div className="slider-row">
            <label>Posición horizontal</label>
            <input
              type="range"
              min="0"
              max="100"
              value={currentModeCfg.posX}
              style={{ '--p': `${currentModeCfg.posX}%` } as any}
              onChange={e => updateSettingField(`modes.@.posX`, Number(e.target.value))}
            />
            <output>{currentModeCfg.posX}%</output>
          </div>

          <div className="slider-row">
            <label>Posición vertical</label>
            <input
              type="range"
              min="0"
              max="100"
              value={currentModeCfg.posY}
              style={{ '--p': `${currentModeCfg.posY}%` } as any}
              onChange={e => updateSettingField(`modes.@.posY`, Number(e.target.value))}
            />
            <output>{currentModeCfg.posY}%</output>
          </div>

          <div className="row center-y" style={{ flexWrap: 'wrap' }}>
            <div className="txt">
              <b>Fondos animados</b>
              <span>Lluvia, luciérnagas, fuego… En pausa se ve la versión fija.</span>
            </div>
            <div className="seg" role="group" aria-label="Fondos animados">
              {(['auto', 'on', 'off'] as const).map(a => (
                <button
                  key={a}
                  aria-pressed={settings.appearance.animation === a}
                  onClick={() => updateSettingField('appearance.animation', a)}
                >
                  {{ auto: 'Automático', on: 'Activados', off: 'En pausa' }[a]}
                </button>
              ))}
            </div>
          </div>

          <div className="section-actions">
            <button
              className="btn ghost"
              onClick={() => {
                updateSettingField(`modes.@`, clone(DEFAULTS.modes[editMode as keyof typeof DEFAULTS.modes]));
                onToast('Modo restaurado a su configuración predeterminada.');
              }}
            >
              Restaurar este modo
            </button>
          </div>
        </div>

        {/* Library of backgrounds */}
        <div className="card">
          <h3>Biblioteca de fondos</h3>
          <div className="chips" role="group" aria-label="Categorías">
            {(CATEGORIES as [string, string][]).map(([id, n]) => (
              <button
                key={id}
                className="chip"
                aria-pressed={libCat === id}
                onClick={() => setLibCat(id)}
              >
                {n}
              </button>
            ))}
          </div>

          {(cats as [string, string][]).map(([cid, cname]) => {
            const scenes = SCENES.filter(s =>
              cid === 'animated' ? !!s.anim : s.cats.includes(cid as any)
            );
            const items =
              cid === 'gradient'
                ? [
                    ...scenes.map(s => ({ kind: 'scene', id: s.id, name: s.name, anim: !!s.anim })),
                    ...(SOLIDS as [string, string][]).map(([c, n]) => ({ kind: 'color', color: c, name: n, anim: false })),
                    { kind: 'custom', name: 'Color propio', anim: false },
                  ]
                : scenes.map(s => ({ kind: 'scene', id: s.id, name: s.name, anim: !!s.anim }));

            const isAll = libCat !== 'all' || seeAll.has(cid);
            const toggleSee = () => {
              const next = new Set(seeAll);
              if (next.has(cid)) next.delete(cid);
              else next.add(cid);
              setSeeAll(next);
            };

            return (
              <div key={cid} className="lib-group">
                <div className="lib-head">
                  <h4>{cname}</h4>
                  {libCat === 'all' && items.length > 3 && (
                    <button className="link-btn" onClick={toggleSee}>
                      {isAll ? 'Ver menos' : `Ver todos (${items.length})`}
                    </button>
                  )}
                </div>

                <div className={`lib-row ${isAll ? 'grid' : ''}`}>
                  {items.map((it: any, idx) => {
                    if (it.kind === 'custom') {
                      const isCustom =
                        bg.kind === 'color' && !(SOLIDS as [string, string][]).some(s => s[0] === bg.color);
                      return (
                        <label key="custom-color" className="thumb" aria-pressed={isCustom}>
                          <span
                            className="img"
                            style={{
                              background:
                                'conic-gradient(from 90deg,#ef4444,#f59e0b,#22c55e,#06b6d4,#7c3aed,#ef4444)',
                              display: 'grid',
                              placeItems: 'center',
                            }}
                          >
                            <input
                              type="color"
                              value={isCustom ? bg.color : '#334155'}
                              style={{ width: '44px', height: '44px' }}
                              onChange={e =>
                                updateSettingField(`modes.@.bg`, {
                                  kind: 'color',
                                  color: e.target.value,
                                })
                              }
                            />
                          </span>
                          Color propio
                        </label>
                      );
                    }

                    const isSelected =
                      (it.kind === 'scene' && bg.kind === 'scene' && bg.id === it.id) ||
                      (it.kind === 'color' && bg.kind === 'color' && bg.color === it.color);

                    return (
                      <button
                        key={it.id || it.color || idx}
                        className="thumb"
                        aria-pressed={isSelected}
                        onClick={() => {
                          if (it.kind === 'scene') {
                            updateSettingField(`modes.@.bg`, { kind: 'scene', id: it.id });
                          } else {
                            updateSettingField(`modes.@.bg`, { kind: 'color', color: it.color });
                          }
                        }}
                      >
                        <span
                          className="img"
                          style={{
                            backgroundColor: it.kind === 'color' ? it.color : '#1b1b22',
                            backgroundImage:
                              it.kind === 'scene' ? `url("${getThumbURL(it.id)}")` : undefined,
                          }}
                        >
                          {it.anim && (
                            <span className="tag">
                              <Icon name="sparkles" /> Animado
                            </span>
                          )}
                        </span>
                        {it.name}
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Accent Color */}
        <div className="card">
          <h3>Color de acento</h3>
          <p className="desc">Botones activos, interruptores y barras.</p>
          <div className="swatches">
            {[
              '#7c3aed',
              '#6d28d9',
              '#db2777',
              '#2563eb',
              '#0891b2',
              '#059669',
              '#d97706',
              '#dc2626',
            ].map(col => (
              <button
                key={col}
                className="swatch"
                style={{ background: col }}
                aria-pressed={settings.appearance.accent === col}
                onClick={() => updateSettingField('appearance.accent', col)}
              />
            ))}
            <input
              type="color"
              value={settings.appearance.accent}
              title="Otro color"
              onChange={e => updateSettingField('appearance.accent', e.target.value)}
            />
          </div>
        </div>
      </div>
    );
  };

  /* ----- Clock Tab Render ----- */
  const renderClock = () => {
    const c = settings.clock;
    const styles: [string, string][] = [
      ['bold', 'Predeterminado grueso'],
      ['thin', 'Predeterminado fino'],
      ['minimal', 'Minimal'],
      ['serif', 'Serif'],
      ['hand', 'Manuscrito'],
      ['minimal-light', 'Minimal liviano'],
      ['serif-condensed', 'Serif condensado'],
    ];

    return (
      <div className="content-inner">
        <h1 id="setTitle">Reloj</h1>
        <p className="sub-t">Personalizá el reloj y los saludos.</p>

        <div className="card">
          <h3>Formato</h3>
          <p className="desc">Reloj de 12 o de 24 horas.</p>
          <div className="opt-grid two">
            {[
              ['12', '12 horas', '2:24'],
              ['24', '24 horas', '14:24'],
            ].map(([v, n, t]) => (
              <button
                key={v}
                className="opt"
                aria-pressed={c.format === v}
                onClick={() => updateSettingField('clock.format', v)}
              >
                <span className="face photo" style={{ backgroundColor: '#1a103c' }}>
                  <span
                    className="fclock"
                    style={{
                      fontFamily: 'var(--display-font)',
                      fontWeight: 800,
                      fontSize: '34px',
                    }}
                  >
                    {t}
                  </span>
                </span>
                {n}
              </button>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="row center-y">
            <div className="txt">
              <b>Reloj con efecto flip</b>
              <span>Las cifras giran al cambiar.</span>
            </div>
            <button
              className="switch"
              role="switch"
              aria-checked={c.flip}
              onClick={() => updateSettingField('clock.flip', !c.flip)}
            />
          </div>

          <div className="row center-y">
            <div className="txt">
              <b>Mostrar segundos</b>
              <span>Muestra la hora con segundos.</span>
            </div>
            <button
              className="switch"
              role="switch"
              aria-checked={c.seconds}
              onClick={() => updateSettingField('clock.seconds', !c.seconds)}
            />
          </div>

          <div className="row center-y">
            <div className="txt">
              <b>Mostrar fecha</b>
              <span>Día y fecha debajo del reloj en Home.</span>
            </div>
            <button
              className="switch"
              role="switch"
              aria-checked={c.date}
              onClick={() => updateSettingField('clock.date', !c.date)}
            />
          </div>

          <div className="row center-y">
            <div className="txt">
              <b>Saludos dinámicos</b>
              <span>Cambian según el día y la hora. Apagado: saludo simple.</span>
            </div>
            <button
              className="switch"
              role="switch"
              aria-checked={c.dynamicGreetings}
              onClick={() => updateSettingField('clock.dynamicGreetings', !c.dynamicGreetings)}
            />
          </div>

          <div className="row center-y">
            <div className="txt">
              <b>Mostrar saludos</b>
              <span>Apagado: se oculta el saludo en Home.</span>
            </div>
            <button
              className="switch"
              role="switch"
              aria-checked={c.greetings}
              onClick={() => updateSettingField('clock.greetings', !c.greetings)}
            />
          </div>

          <div className="field" style={{ marginTop: '8px' }}>
            <label htmlFor="nameIn">Tu nombre para los saludos</label>
            <input
              type="text"
              id="nameIn"
              maxLength={40}
              value={settings.name}
              style={{ maxWidth: '280px' }}
              onChange={e => updateSettingField('name', e.target.value)}
            />
          </div>
        </div>

        <div className="card">
          <h3>Estilo del reloj y del temporizador</h3>
          <p className="desc">Se aplica a la hora y a la cuenta regresiva.</p>
          <div className="opt-grid">
            {styles.map(([v, n]) => (
              <button
                key={v}
                className="opt"
                aria-pressed={c.style === v}
                onClick={() => updateSettingField('clock.style', v)}
              >
                <span className="face photo" style={{ backgroundColor: '#1a103c' }}>
                  <span
                    className={`clock style-${v}`}
                    style={{ fontSize: '38px', color: '#fff' }}
                  >
                    9:24
                  </span>
                </span>
                {n}
              </button>
            ))}
          </div>
        </div>

        <div className="card">
          <h3>Apariencia</h3>
          <div className="slider-row">
            <label>Tamaño</label>
            <input
              type="range"
              min="50"
              max="170"
              step="5"
              value={c.size}
              style={{ '--p': `${((c.size - 50) / 120) * 100}%` } as any}
              onChange={e => updateSettingField('clock.size', Number(e.target.value))}
            />
            <output>{c.size}%</output>
          </div>

          <div className="row center-y">
            <div className="txt">
              <b>Color</b>
            </div>
            <div className="swatches">
              {['#ffffff', '#fff4e0', '#e9ddff', '#d6f5e8', '#ffd9e6', '#cfe8ff'].map(col => (
                <button
                  key={col}
                  className="swatch"
                  style={{ background: col }}
                  aria-pressed={c.color === col}
                  onClick={() => updateSettingField('clock.color', col)}
                />
              ))}
              <input
                type="color"
                value={c.color}
                onChange={e => updateSettingField('clock.color', e.target.value)}
              />
            </div>
          </div>

          <div className="section-actions">
            <button
              className="btn ghost"
              onClick={() => {
                updateSettingField('clock', clone(DEFAULTS.clock));
                onToast('Reloj restaurado a su configuración predeterminada.');
              }}
            >
              Restaurar reloj
            </button>
          </div>
        </div>
      </div>
    );
  };

  /* ----- Timer Tab Render ----- */
  const renderTimer = () => {
    const t = settings.timer;
    const pomo = t.mode === 'pomodoro';
    const activeTask = tasks.find(x => x.active && !x.deleted && !x.done);

    const timerStyles = [
      ['default', 'Predeterminado', <span key="def" style={{ fontSize: '24px', fontWeight: 600 }}>25:00</span>],
      [
        'flip',
        'Flip',
        <span key="flip" style={{ display: 'flex', gap: '6px' }}>
          <b style={{ background: '#2a2a32', padding: '6px 9px', borderRadius: '5px', fontSize: '20px' }}>2</b>
          <b style={{ background: '#2a2a32', padding: '6px 9px', borderRadius: '5px', fontSize: '20px' }}>5</b>
        </span>,
      ],
      [
        'bar',
        'Barra de progreso',
        <span key="bar" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '6px' }}>
          <small className="fsmall">25:00</small>
          <i style={{ display: 'block', width: '110px', height: '7px', borderRadius: '9px', background: 'linear-gradient(90deg,#fff 62%,#555 62%)' }} />
        </span>,
      ],
      [
        'gauge',
        'Medidor',
        <span key="gauge" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <svg width="36" height="36" viewBox="0 0 36 36">
            <circle cx="18" cy="18" r="14" fill="none" stroke="#555" strokeWidth="5" />
            <circle cx="18" cy="18" r="14" fill="none" stroke="#fff" strokeWidth="5" strokeDasharray="88" strokeDashoffset="22" transform="rotate(-90 18 18)" />
          </svg>
          <small className="fsmall">25:00</small>
        </span>,
      ],
      [
        'dots',
        'Matriz de puntos',
        <span key="dots" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '4px' }}>
          <span style={{ display: 'grid', gridTemplateColumns: 'repeat(8,5px)', gap: '3px' }}>
            {Array.from({ length: 24 }, (_, i) => (
              <i key={i} style={{ width: '5px', height: '5px', background: '#fff', opacity: i < 17 ? 1 : 0.3 }} />
            ))}
          </span>
          <small className="fsmall">25:00</small>
        </span>,
      ],
      [
        'pie',
        'Torta',
        <span key="pie" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
          <svg width="34" height="34" viewBox="0 0 34 34">
            <circle cx="17" cy="17" r="15" fill="#555" />
            <path d="M17 17V2a15 15 0 1 1-15 15z" fill="#fff" />
          </svg>
          <small className="fsmall">25:00</small>
        </span>,
      ],
    ];

    const alerts = audioX.getAlerts() as Record<string, { name: string }>;

    return (
      <div className="content-inner">
        <h1 id="setTitle">Temporizador</h1>
        <p className="sub-t">Ajustalo a tu forma de estudiar.</p>

        <div className="card">
          <div className="field">
            <label htmlFor="tmMode">Modo del temporizador</label>
            <select
              id="tmMode"
              value={t.mode}
              onChange={e => updateSettingField('timer.mode', e.target.value)}
            >
              <option value="pomodoro">Pomodoro (foco + descansos)</option>
              <option value="countdown">Cuenta regresiva simple</option>
            </select>
          </div>

          {pomo && (
            <div className="row center-y">
              <div className="txt">
                <b>Usar la estimación de la tarea</b>
                <span>
                  El foco dura lo que falta de la estimación de la tarea activa.{' '}
                  {activeTask
                    ? activeTask.estimate
                      ? `Ahora: “${activeTask.title}”.`
                      : `“${activeTask.title}” no tiene estimación.`
                    : 'Sin tarea activa: se usa la duración de foco.'}
                </span>
              </div>
              <button
                className="switch"
                role="switch"
                aria-checked={t.etaMode}
                onClick={() => updateSettingField('timer.etaMode', !t.etaMode)}
              />
            </div>
          )}

          <h3 style={{ marginTop: '14px' }}>Duraciones</h3>
          <p className="desc">Se aplican a partir de la próxima etapa.</p>

          <div className="fields">
            {pomo ? (
              <>
                <div className="field">
                  <label>Foco</label>
                  <span className="num">
                    <input
                      type="number"
                      min="1"
                      max="240"
                      value={t.focus}
                      onChange={e => updateSettingField('timer.focus', Number(e.target.value))}
                    />
                    <span>min</span>
                  </span>
                </div>
                <div className="field">
                  <label>Descanso corto</label>
                  <span className="num">
                    <input
                      type="number"
                      min="1"
                      max="120"
                      value={t.short}
                      onChange={e => updateSettingField('timer.short', Number(e.target.value))}
                    />
                    <span>min</span>
                  </span>
                </div>
                <div className="field">
                  <label>Descanso largo</label>
                  <span className="num">
                    <input
                      type="number"
                      min="1"
                      max="180"
                      value={t.long}
                      onChange={e => updateSettingField('timer.long', Number(e.target.value))}
                    />
                    <span>min</span>
                  </span>
                </div>
                <div className="field">
                  <label>Sesiones hasta largo</label>
                  <span className="num">
                    <input
                      type="number"
                      min="1"
                      max="12"
                      value={t.cycles}
                      onChange={e => updateSettingField('timer.cycles', Number(e.target.value))}
                    />
                    <span>ses.</span>
                  </span>
                </div>
              </>
            ) : (
              <div className="field">
                <label>Cuenta regresiva</label>
                <span className="num">
                  <input
                    type="number"
                    min="1"
                    max="600"
                    value={t.countdown}
                    onChange={e => updateSettingField('timer.countdown', Number(e.target.value))}
                  />
                  <span>min</span>
                </span>
              </div>
            )}
          </div>
        </div>

        <div className="card">
          <h3>Estilo del temporizador</h3>
          <p className="desc">Cómo se muestra el tiempo restante.</p>
          <div className="opt-grid">
            {timerStyles.map(([v, n, face]) => (
              <button
                key={v as string}
                className="opt"
                aria-pressed={t.style === v}
                onClick={() => updateSettingField('timer.style', v)}
              >
                <span className="face">{face}</span>
                {n as string}
              </button>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="row center-y">
            <div className="txt">
              <b>Barra de progreso</b>
              <span>Una línea fina debajo del temporizador.</span>
            </div>
            <button
              className="switch"
              role="switch"
              aria-checked={t.progressBar}
              onClick={() => updateSettingField('timer.progressBar', !t.progressBar)}
            />
          </div>

          <div className="row center-y">
            <div className="txt">
              <b>Notificación al terminar</b>
              <span>Aviso del sistema si estás en otra pestaña.</span>
            </div>
            <button
              className="switch"
              role="switch"
              aria-checked={t.notify}
              onClick={async () => {
                if (!t.notify && 'Notification' in window) {
                  const perm = await Notification.requestPermission();
                  if (perm !== 'granted') return;
                }
                updateSettingField('timer.notify', !t.notify);
              }}
            />
          </div>

          <div className="row center-y">
            <div className="txt">
              <b>{pomo ? 'Iniciar descansos automáticamente' : 'Reiniciar automáticamente'}</b>
              <span>
                {pomo
                  ? 'Al terminar el foco, el descanso arranca solo.'
                  : 'Al terminar, la cuenta vuelve a empezar.'}
              </span>
            </div>
            <button
              className="switch"
              role="switch"
              aria-checked={t.autoBreak}
              onClick={() => updateSettingField('timer.autoBreak', !t.autoBreak)}
            />
          </div>

          {pomo && (
            <div className="row center-y">
              <div className="txt">
                <b>Iniciar el foco automáticamente</b>
                <span>Al terminar un descanso, la siguiente sesión arranca sola.</span>
              </div>
              <button
                className="switch"
                role="switch"
                aria-checked={t.autoFocus}
                onClick={() => updateSettingField('timer.autoFocus', !t.autoFocus)}
              />
            </div>
          )}

          <div className="row center-y">
            <div className="txt">
              <b>Mostrar racha en la pantalla</b>
              <span>El contador 🔥 abajo a la derecha.</span>
            </div>
            <button
              className="switch"
              role="switch"
              aria-checked={t.showStreak}
              onClick={() => updateSettingField('timer.showStreak', !t.showStreak)}
            />
          </div>

          <div className="field" style={{ marginTop: '8px' }}>
            <label>Minutos de foco para que un día sume a la racha</label>
            <span className="num">
              <input
                type="number"
                min="1"
                max="600"
                value={t.streakGoal}
                onChange={e => updateSettingField('timer.streakGoal', Number(e.target.value))}
              />
              <span>min</span>
            </span>
          </div>
        </div>

        <div className="card">
          <h3>Sonido de alerta</h3>
          <p className="desc">Suena al terminar cada etapa. Tocá uno para escucharlo.</p>
          <div
            className="seg outline-chips"
            role="group"
            aria-label="Sonido de alerta"
            style={{ marginBottom: '14px' }}
          >
            {Object.entries(alerts).map(([id, a]) => (
              <button
                key={id}
                aria-pressed={t.sound === id}
                onClick={() => {
                  updateSettingField('timer.sound', id);
                  audioX.playAlert(id, t.volume);
                }}
              >
                {a.name}
              </button>
            ))}
          </div>

          <div className="slider-row">
            <label>Volumen</label>
            <input
              type="range"
              min="0"
              max="100"
              value={t.volume}
              style={{ '--p': `${t.volume}%` } as any}
              onChange={e => updateSettingField('timer.volume', Number(e.target.value))}
            />
            <output>{t.volume}%</output>
          </div>
        </div>

        <div className="card">
          <h3>Marcas de sesión</h3>
          <p className="desc">
            Cada marca es una sesión de foco completa dentro del ciclo actual.
          </p>
          <div className="seg" role="group" aria-label="Marcas de sesión">
            {(['dots', 'numbers', 'none'] as const).map(m => (
              <button
                key={m}
                aria-pressed={t.tallies === m}
                onClick={() => updateSettingField('timer.tallies', m)}
              >
                {{ dots: 'Puntos', numbers: 'Números', none: 'Ocultas' }[m]}
              </button>
            ))}
          </div>

          <div className="section-actions">
            <button
              className="btn ghost"
              onClick={() => {
                updateSettingField('timer', clone(DEFAULTS.timer));
                onToast('Temporizador restaurado a su configuración predeterminada.');
              }}
            >
              Restaurar temporizador
            </button>
          </div>
        </div>
      </div>
    );
  };

  /* ----- Stats Tab Render ----- */
  const renderStats = () => {
    const focusSessions = sessions.filter(s => s.kind === 'focus');
    const totalFocusMs = focusSessions.reduce((acc, s) => acc + s.ms, 0);
    const breakSessions = sessions.filter(s => s.kind !== 'focus');
    const totalBreakMs = breakSessions.reduce((acc, s) => acc + s.ms, 0);

    // Compute streak
    const goalMs = settings.timer.streakGoal * 60000;
    const dayMap = new Map<string, number>();
    focusSessions.forEach(s => {
      const k = dayKey(s.start);
      dayMap.set(k, (dayMap.get(k) || 0) + s.ms);
    });

    let currentStreak = 0;
    let bestStreak = 0;
    let tempStreak = 0;

    let checkD = startOfDay(Date.now());
    if ((dayMap.get(dayKey(checkD)) || 0) >= goalMs) {
      currentStreak++;
      checkD = addDays(checkD, -1);
    } else {
      checkD = addDays(checkD, -1);
    }
    while ((dayMap.get(dayKey(checkD)) || 0) >= goalMs) {
      currentStreak++;
      checkD = addDays(checkD, -1);
    }

    // Best streak
    const sortedDays = Array.from(dayMap.keys()).sort();
    let prevD: number | null = null;
    sortedDays.forEach(dk => {
      if ((dayMap.get(dk) || 0) >= goalMs) {
        const curD = startOfDay(new Date(dk).getTime());
        if (prevD !== null && curD - prevD === 86400000) {
          tempStreak++;
        } else {
          tempStreak = 1;
        }
        prevD = curD;
        if (tempStreak > bestStreak) bestStreak = tempStreak;
      }
    });

    const completedTasksCount = tasks.filter(t => t.done && !t.deleted).length;

    // Dist by task
    const distMap = new Map<string, { name: string; ms: number }>();
    focusSessions.forEach(s => {
      const key = s.taskId || s.title || 'Foco';
      const existing = distMap.get(key) || { name: s.title || 'Foco', ms: 0 };
      existing.ms += s.ms;
      distMap.set(key, existing);
    });
    const distList = Array.from(distMap.values()).sort((a, b) => b.ms - a.ms);

    // Heatmap calculation
    const weeks = heatSpan === '6m' ? 26 : 53;
    const today = startOfDay(Date.now());
    const dow = (new Date(today).getDay() + 6) % 7;
    const heatStart = addDays(today, -dow - (weeks - 1) * 7);

    const heatCells: React.ReactNode[] = [];
    for (let i = 0; i < weeks * 7; i++) {
      const t = addDays(heatStart, i);
      const k = dayKey(t);
      if (t > today) {
        heatCells.push(<i key={i} className="future" />);
        continue;
      }
      const val = dayMap.get(k) || 0;
      let lvl = 0;
      if (val > 0) {
        if (val < 30 * 60000) lvl = 1;
        else if (val < 90 * 60000) lvl = 2;
        else if (val < 180 * 60000) lvl = 3;
        else lvl = 4;
      }
      const label = `${new Date(t).toLocaleDateString('es-AR', {
        day: 'numeric',
        month: 'short',
      })}: ${val ? fmtDur(val) : 'sin foco'}`;

      heatCells.push(<i key={i} className={lvl ? `l${lvl}` : ''} title={label} />);
    }

    const handleDeleteSession = (id: string) => {
      const next = sessions.filter(s => s.id !== id);
      onUpdateSessions(next);
      Store.saveSessions(next);
      sync.touch();
    };

    return (
      <div className="content-inner">
        <h1 id="setTitle">Estadísticas</h1>
        <p className="sub-t">
          Salen de tus sesiones reales en este navegador. Pausas y descansos no cuentan como foco.
        </p>

        <div className="stat-cards">
          <div className="stat c1">
            <div className="s-top">
              Racha actual <Icon name="flameO" />
            </div>
            <div className="s-val">
              {currentStreak} {currentStreak === 1 ? 'día' : 'días'}
            </div>
            <div className="s-foot">
              Mejor: {bestStreak} · meta {settings.timer.streakGoal} min/día
            </div>
          </div>
          <div className="stat c2">
            <div className="s-top">
              Tiempo de foco <Icon name="bolt" />
            </div>
            <div className="s-val">{fmtDur(totalFocusMs)}</div>
            <div className="s-foot">Total acumulado</div>
          </div>
          <div className="stat c3">
            <div className="s-top">
              Sesiones <Icon name="stopwatch" />
            </div>
            <div className="s-val">{focusSessions.filter(s => s.completed).length}</div>
            <div className="s-foot">
              + {focusSessions.filter(s => !s.completed).length} interrumpidas
            </div>
          </div>
          <div className="stat c4">
            <div className="s-top">
              Tareas completadas <Icon name="listcheck" />
            </div>
            <div className="s-val">{completedTasksCount}</div>
            <div className="s-foot">En tu lista</div>
          </div>
          <div className="stat c5">
            <div className="s-top">
              Descanso <Icon name="coffee" />
            </div>
            <div className="s-val">{fmtDur(totalBreakMs)}</div>
            <div className="s-foot">No suma al foco</div>
          </div>
          <div className="stat c6">
            <div className="s-top">
              Promedio <Icon name="gauge" />
            </div>
            <div className="s-val">
              {focusSessions.length > 0
                ? fmtDur(Math.round(totalFocusMs / focusSessions.length))
                : '0 min'}
            </div>
            <div className="s-foot">Por sesión</div>
          </div>
        </div>

        {/* Heatmap */}
        <div className="card">
          <h3>Calendario de foco</h3>
          <div
            style={{
              display: 'flex',
              justifyContent: 'space-between',
              gap: '10px',
              flexWrap: 'wrap',
              margin: '10px 0 14px',
            }}
          >
            <div className="seg" role="group" aria-label="Rango">
              {(['6m', '1y'] as const).map(s => (
                <button
                  key={s}
                  aria-pressed={heatSpan === s}
                  onClick={() => setHeatSpan(s)}
                >
                  {{ '6m': '6 meses', '1y': '1 año' }[s]}
                </button>
              ))}
            </div>
          </div>

          <div
            className="heat-wrap"
            role="img"
            aria-label={`Calendario de foco de los últimos ${
              heatSpan === '6m' ? '6 meses' : '12 meses'
            }`}
          >
            <div className="heat">{heatCells}</div>
          </div>
          <div className="legend">
            <span>
              {new Date(heatStart).toLocaleDateString('es-AR', {
                day: 'numeric',
                month: 'short',
                year: 'numeric',
              })}
            </span>
            <span className="scale">
              Menos <i style={{ background: '#1a1a26' }} />
              <i style={{ background: '#3b2a6b' }} />
              <i style={{ background: '#5431a8' }} />
              <i style={{ background: '#7440e0' }} />
              <i style={{ background: '#a07bff' }} /> Más
            </span>
            <span>
              {new Date(today).toLocaleDateString('es-AR', {
                day: 'numeric',
                month: 'short',
                year: 'numeric',
              })}
            </span>
          </div>
        </div>

        {/* Distribution by task */}
        <div className="card">
          <h3>Por tarea</h3>
          <p className="desc">Tiempo de foco según la tarea o actividad.</p>
          {distList.length > 0 ? (
            <div className="dist">
              {distList.slice(0, 8).map(d => (
                <div key={d.name} className="dist-row">
                  <span className="n">{d.name}</span>
                  <span className="v">
                    {fmtDur(d.ms)} · {Math.round((d.ms / totalFocusMs) * 100 || 0)}%
                  </span>
                  <span className="b">
                    <i
                      style={{
                        width: `${Math.round((d.ms / distList[0].ms) * 100)}%`,
                      }}
                    />
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="empty">
              <strong>Sin foco registrado</strong>
              Asociá una tarea con ◎ en el panel de tareas para ver el reparto.
            </div>
          )}
        </div>

        {/* Session history */}
        <div className="card">
          <h3>Historial de sesiones</h3>
          {sessions.length > 0 ? (
            <>
              <ul className="hist">
                {sessions.slice(0, histLimit).map(s => {
                  const d = new Date(s.start);
                  const e = new Date(s.end);
                  return (
                    <li key={s.id}>
                      <div>
                        <div className="h-t">
                          {s.title || (s.kind === 'focus' ? 'Foco' : 'Descanso')}
                          <span className={`pill ${s.completed ? 'ok' : 'warn'}`}>
                            {s.completed ? 'Completa' : 'Interrumpida'}
                          </span>
                        </div>
                        <div className="h-s">
                          {d.toLocaleDateString('es-AR', { day: 'numeric', month: 'short' })} ·{' '}
                          {d.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })}–
                          {e.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' })}
                        </div>
                      </div>
                      <div className="h-d">{fmtDur(s.ms)}</div>
                      <button
                        className="mini"
                        aria-label="Eliminar sesión"
                        onClick={() => handleDeleteSession(s.id)}
                      >
                        <Icon name="trash" />
                      </button>
                    </li>
                  );
                })}
              </ul>
              {sessions.length > histLimit && (
                <div className="section-actions" style={{ justifyContent: 'center' }}>
                  <button
                    className="btn ghost"
                    onClick={() => setHistLimit(prev => prev + 20)}
                  >
                    Ver más ({sessions.length - histLimit})
                  </button>
                </div>
              )}
            </>
          ) : (
            <div className="empty">
              <strong>Todavía no hay sesiones acá</strong>
              Iniciá el temporizador en Focus: cada sesión completa o interrumpida queda registrada.
            </div>
          )}
        </div>
      </div>
    );
  };

  /* ----- Quotes Tab Render ----- */
  const renderQuotes = () => {
    const q = settings.quotes;

    return (
      <div className="content-inner">
        <h1 id="setTitle">Frases</h1>
        <p className="sub-t">Una frase tranquila arriba a la derecha.</p>

        <div className="card">
          <div className="row center-y">
            <div className="txt">
              <b>Mostrar frases</b>
              <span>Apagado: la esquina queda libre.</span>
            </div>
            <button
              className="switch"
              role="switch"
              aria-checked={q.show}
              onClick={() => updateSettingField('quotes.show', !q.show)}
            />
          </div>

          <div className="field" style={{ marginTop: '6px' }}>
            <label htmlFor="qRot">Cambiar de frase</label>
            <select
              id="qRot"
              value={q.rotation}
              onChange={e => updateSettingField('quotes.rotation', e.target.value)}
            >
              <option value="daily">Una por día</option>
              <option value="hourly">Cada hora</option>
              <option value="visit">Cada vez que abro la app</option>
            </select>
          </div>
        </div>

        <div className="card">
          <h3>Tu frase</h3>
          <p className="desc">Si la activás, reemplaza a las frases incluidas.</p>
          <textarea
            maxLength={200}
            rows={3}
            placeholder="Por ejemplo: Paso a paso, Gonzalo."
            value={q.custom}
            onChange={e => updateSettingField('quotes.custom', e.target.value)}
          />
          <div className="row center-y">
            <div className="txt">
              <b>Usar mi frase</b>
              <span>{q.custom.trim() ? '' : 'Escribí una frase para poder activarla.'}</span>
            </div>
            <button
              className="switch"
              role="switch"
              disabled={!q.custom.trim()}
              aria-checked={q.useCustom}
              onClick={() => updateSettingField('quotes.useCustom', !q.useCustom)}
            />
          </div>
        </div>

        <div className="card">
          <h3>Incluidas</h3>
          <p className="desc">{QUOTES.length} frases cortas en español.</p>
          <ul
            style={{
              margin: 0,
              paddingLeft: '18px',
              color: 'var(--muted)',
              columns: 2,
              columnGap: '28px',
              fontSize: '14px',
            }}
          >
            {QUOTES.map(x => (
              <li key={x} style={{ marginBottom: '6px' }}>
                {x}
              </li>
            ))}
          </ul>
        </div>
      </div>
    );
  };

  /* ----- Extras Tab Render ----- */
  const renderExtras = () => {
    const isFsActive = !!(document.fullscreenElement || (document as any).webkitFullscreenElement);

    const toggleFs = async () => {
      try {
        if (isFsActive) {
          if (document.exitFullscreen) await document.exitFullscreen();
          else if ((document as any).webkitExitFullscreen)
            await (document as any).webkitExitFullscreen();
        } else {
          if (document.documentElement.requestFullscreen)
            await document.documentElement.requestFullscreen();
          else if ((document as any).webkitRequestFullscreen)
            await (document as any).webkitRequestFullscreen();
        }
      } catch {
        onToast('El navegador no permitió la pantalla completa acá.', 'err');
      }
    };

    return (
      <div className="content-inner">
        <h1 id="setTitle">Extras</h1>
        <p className="sub-t">Detalles para concentrarte mejor.</p>

        <div className="card">
          <div className="row center-y">
            <div className="txt">
              <b>Ocultar controles al concentrarte</b>
              <span>
                Con el temporizador corriendo (o en Ambient), los controles se desvanecen y vuelven
                al mover el mouse, tocar o usar el teclado.
              </span>
            </div>
            <button
              className="switch"
              role="switch"
              aria-checked={settings.appearance.autoHide}
              onClick={() =>
                updateSettingField('appearance.autoHide', !settings.appearance.autoHide)
              }
            />
          </div>

          {settings.appearance.autoHide && (
            <div className="slider-row">
              <label>Ocultar después de</label>
              <input
                type="range"
                min="2"
                max="60"
                value={settings.appearance.autoHideDelay}
                style={
                  {
                    '--p': `${((settings.appearance.autoHideDelay - 2) / 58) * 100}%`,
                  } as any
                }
                onChange={e =>
                  updateSettingField('appearance.autoHideDelay', Number(e.target.value))
                }
              />
              <output>{settings.appearance.autoHideDelay} s</output>
            </div>
          )}

          <div className="row center-y">
            <div className="txt">
              <b>Mostrar el logo</b>
              <span>La palabra “foco” arriba a la izquierda.</span>
            </div>
            <button
              className="switch"
              role="switch"
              aria-checked={settings.appearance.showLogo}
              onClick={() =>
                updateSettingField('appearance.showLogo', !settings.appearance.showLogo)
              }
            />
          </div>
        </div>

        <div className="card">
          <h3>Pantalla completa</h3>
          <p className="desc">También con la tecla F o el botón de abajo a la derecha.</p>
          <button className="btn" onClick={toggleFs}>
            <Icon name="expand" /> {isFsActive ? 'Salir de pantalla completa' : 'Entrar en pantalla completa'}
          </button>
        </div>

        <div className="card">
          <h3>Atajos de teclado</h3>
          <div className="kbd-list">
            <kbd>Espacio</kbd>
            <span>Iniciar o pausar</span>
            <kbd>R</kbd>
            <span>Reiniciar la etapa</span>
            <kbd>N</kbd>
            <span>Pasar a la siguiente etapa</span>
            <kbd>1</kbd>
            <span>Modo Home</span>
            <kbd>2</kbd>
            <span>Modo Focus</span>
            <kbd>3</kbd>
            <span>Modo Ambient</span>
            <kbd>T</kbd>
            <span>Tareas</span>
            <kbd>M</kbd>
            <span>Sonidos</span>
            <kbd>F</kbd>
            <span>Pantalla completa</span>
            <kbd>,</kbd>
            <span>Ajustes</span>
            <kbd>Esc</kbd>
            <span>Cerrar panel</span>
          </div>
        </div>

        <div className="card">
          <h3>Integraciones</h3>
          <p className="desc" style={{ margin: 0 }}>
            No hay conexión con Spotify, YouTube ni cuentas externas: los ambientes sonoros
            funcionan sin conexión mediante síntesis web audio.
          </p>
        </div>
      </div>
    );
  };

  /* ----- Data Tab Render ----- */
  const renderData = () => {
    const meta = sync.getMeta();
    const server = sync.getServerStatus();

    const handleConnectSync = async () => {
      const res = await sync.connect(syncKeyInput);
      if (res.ok) {
        onToast('Sincronización conectada con éxito.');
        setSyncKeyInput('');
      } else {
        onToast(res.msg || 'Error al conectar.', 'err');
      }
    };

    const handleExportJSON = () => {
      const payload = {
        app: 'foco',
        version: 1,
        exportedAt: new Date().toISOString(),
        settings,
        tasks: { v: 1, items: tasks },
        history: { v: 1, sessions },
        notes: Store.loadNotes(),
      };
      const json = JSON.stringify(payload, null, 2);
      const name = `foco-respaldo-${dayKey(Date.now())}.json`;
      const a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob([json], { type: 'application/json' }));
      a.download = name;
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        URL.revokeObjectURL(a.href);
        a.remove();
      }, 1000);
      onToast('Copia exportada.');
    };

    const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const doc = JSON.parse(reader.result as string);
          if (doc.app !== 'foco') {
            onToast('El archivo no es una copia válida de foco.', 'err');
            return;
          }
          onConfirm(
            '¿Restaurar copia de seguridad?',
            'Se reemplazarán ajustes, tareas, historial y notas con el contenido del archivo.',
            'Restaurar',
            () => {
              if (doc.settings) onUpdateSettings(doc.settings);
              if (doc.tasks?.items) {
                onUpdateTasks(doc.tasks.items);
                Store.saveTaskItems(doc.tasks.items);
              }
              if (doc.history?.sessions) {
                onUpdateSessions(doc.history.sessions);
                Store.saveSessions(doc.history.sessions);
              }
              if (doc.notes != null) {
                Store.saveNotes(typeof doc.notes === 'string' ? doc.notes : doc.notes.text);
              }
              onToast('Copia importada con éxito.');
            }
          );
        } catch {
          onToast('Error al leer el archivo JSON.', 'err');
        }
      };
      reader.readAsText(file);
    };

    const handleClearHistory = () => {
      onConfirm(
        '¿Borrar historial?',
        'Elimina sesiones, rachas y tareas completadas de las estadísticas.',
        'Borrar historial',
        () => {
          onUpdateSessions([]);
          Store.saveSessions([]);
          onToast('Historial borrado.');
        }
      );
    };

    const handleResetAll = () => {
      onConfirm(
        '¿Restablecer todo?',
        'Vuelve a la configuración inicial y elimina tareas, notas, historial e imágenes propias.',
        'Restablecer todo',
        async () => {
          await imageDB.clear();
          localStorage.clear();
          window.location.reload();
        }
      );
    };

    return (
      <div className="content-inner">
        <h1 id="setTitle">Datos</h1>
        <p className="sub-t">Tus datos viven solo en este navegador.</p>

        {/* Sync Card */}
        <div className="card">
          <h3>
            <Icon name="data" /> Sincronización en la nube
          </h3>
          {meta.connected ? (
            <>
              <p className="desc">
                {meta.lastError ? (
                  <span className="err">{meta.lastError}</span>
                ) : (
                  `Conectado · última sincronización ${
                    meta.lastSync
                      ? new Date(meta.lastSync).toLocaleTimeString('es-AR')
                      : 'pendiente'
                  }. Los cambios se suben solos.`
                )}
              </p>
              <div className="section-actions" style={{ justifyContent: 'flex-start' }}>
                <button
                  className="btn primary"
                  onClick={async () => {
                    await sync.run();
                    onToast('Sincronización completada.');
                  }}
                >
                  Sincronizar ahora
                </button>
                <button
                  className="btn ghost"
                  onClick={() => {
                    sync.disconnect();
                    onToast('Dispositivo desconectado.');
                  }}
                >
                  Desconectar este dispositivo
                </button>
              </div>
            </>
          ) : (
            <>
              <p className="desc">
                Escribí la clave configurada para sincronizar entre dispositivos.
              </p>
              <div className="add-task">
                <input
                  type="password"
                  placeholder="Clave de sincronización (mínimo 12 caracteres)"
                  value={syncKeyInput}
                  onChange={e => setSyncKeyInput(e.target.value)}
                  style={{ flex: 1 }}
                />
                <button
                  className="btn primary"
                  disabled={syncKeyInput.trim().length < 12}
                  onClick={handleConnectSync}
                >
                  Conectar
                </button>
              </div>
              <p className="hint" style={{ marginTop: '10px' }}>
                {genSyncKey ? (
                  <>
                    Tu clave nueva:{' '}
                    <b style={{ color: 'var(--text)', userSelect: 'all', fontSize: '14px' }}>
                      {genSyncKey}
                    </b>{' '}
                    <button
                      className="link-btn"
                      onClick={() => {
                        navigator.clipboard.writeText(genSyncKey);
                        onToast('Clave copiada al portapapeles.');
                      }}
                    >
                      Copiar
                    </button>
                  </>
                ) : (
                  <>
                    ¿Todavía no tenés clave?{' '}
                    <button
                      className="link-btn"
                      onClick={() => setGenSyncKey(sync.genKey())}
                    >
                      Generar una segura
                    </button>
                  </>
                )}
              </p>
            </>
          )}
        </div>

        {/* Storage location info */}
        <div className="card">
          <h3>Dónde se guardan</h3>
          <p className="desc" style={{ margin: 0 }}>
            Ajustes, tareas, notas e historial se guardan en este navegador; las imágenes propias,
            en IndexedDB y solo en este dispositivo.
          </p>
        </div>

        {/* Backup export and import */}
        <div className="card">
          <h3>Copia de seguridad</h3>
          <p className="desc">
            Archivo JSON con ajustes, {tasks.length} tareas, {sessions.length} sesiones y tus notas.
          </p>
          <div className="section-actions" style={{ justifyContent: 'flex-start' }}>
            <button className="btn primary" onClick={handleExportJSON}>
              <Icon name="download" /> Exportar JSON
            </button>
            <label className="btn" htmlFor="impFile" tabIndex={0}>
              <Icon name="upload" /> Importar JSON
            </label>
            <input
              type="file"
              id="impFile"
              accept="application/json,.json"
              className="sr-only"
              onChange={handleImportJSON}
            />
          </div>
        </div>

        {/* Clear and Reset */}
        <div className="card">
          <h3>Borrar</h3>
          <div className="row center-y">
            <div className="txt">
              <b>Borrar historial</b>
              <span>
                Elimina sesiones, rachas y tareas completadas de las estadísticas. Conserva ajustes
                y tareas.
              </span>
            </div>
            <button className="btn danger" onClick={handleClearHistory}>
              Borrar historial
            </button>
          </div>
          <div className="row center-y">
            <div className="txt">
              <b>Restablecer todo</b>
              <span>
                Vuelve a la configuración inicial y elimina tareas, notas, historial e imágenes
                propias.
              </span>
            </div>
            <button className="btn danger" onClick={handleResetAll}>
              Restablecer
            </button>
          </div>
        </div>
      </div>
    );
  };

  return (
    <>
      <div className="scrim" onClick={onClose} />
      <div
        className="settings"
        role="dialog"
        aria-modal="true"
        aria-labelledby="setTitle"
      >
        <nav className="side" aria-label="Secciones de ajustes">
          <button
            className="x-btn"
            aria-label="Cerrar ajustes"
            onClick={onClose}
          >
            <Icon name="x" />
          </button>
          {NAV_ITEMS.map(([key, label, iconName]) => (
            <button
              key={key}
              className="nav-btn"
              data-nav={key}
              aria-current={section === key ? 'page' : false}
              onClick={() => setSection(key)}
            >
              <Icon name={iconName} /> {label}
            </button>
          ))}
          <div className="side-note">foco · tu espacio de concentración</div>
        </nav>

        <div className="content">
          {section === 'themes' && renderThemes()}
          {section === 'clock' && renderClock()}
          {section === 'timer' && renderTimer()}
          {section === 'stats' && renderStats()}
          {section === 'quotes' && renderQuotes()}
          {section === 'extras' && renderExtras()}
          {section === 'data' && renderData()}
        </div>
      </div>
    </>
  );
};
