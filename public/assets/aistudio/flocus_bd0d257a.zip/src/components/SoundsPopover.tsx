import React, { useEffect, useState } from 'react';
import { Icon } from './Icons';
import { audioX } from '../lib/audio';
import type { Settings } from '../types';

interface SoundsPopoverProps {
  open: boolean;
  onClose: () => void;
  settings: Settings;
  onUpdateSettings: (s: Settings, path?: string) => void;
}

export const SoundsPopover: React.FC<SoundsPopoverProps> = ({
  open,
  onClose,
  settings,
  onUpdateSettings,
}) => {
  const [, setTick] = useState(0);

  useEffect(() => {
    return audioX.subscribe(() => {
      setTick(t => t + 1);
    });
  }, []);

  useEffect(() => {
    if (!open) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [open, onClose]);

  if (!open) return null;

  const ambients = audioX.getAmbients() as Record<string, { name: string; desc: string }>;
  const playingList = audioX.playing();
  const master = settings.sounds.master;

  const toggleSound = (id: string) => {
    audioX.toggle(id);
    const active = audioX.isPlaying(id);
    const nextActive = (settings.sounds.active || []).filter(x => x !== id);
    if (active) nextActive.push(id);
    const nextSettings = {
      ...settings,
      sounds: {
        ...settings.sounds,
        active: nextActive,
      },
    };
    onUpdateSettings(nextSettings, 'sounds.active');
  };

  const handleLevelChange = (id: string, val: number) => {
    audioX.setLevel(id, val);
    const nextLevels = { ...settings.sounds.levels, [id]: val };
    const nextSettings = {
      ...settings,
      sounds: {
        ...settings.sounds,
        levels: nextLevels,
      },
    };
    onUpdateSettings(nextSettings, 'sounds.levels');
  };

  const handleMasterChange = (val: number) => {
    const nextSettings = {
      ...settings,
      sounds: {
        ...settings.sounds,
        master: val,
      },
    };
    onUpdateSettings(nextSettings, 'sounds.master');
  };

  const stopAll = () => {
    audioX.stopAll();
    const nextSettings = {
      ...settings,
      sounds: {
        ...settings.sounds,
        active: [],
      },
    };
    onUpdateSettings(nextSettings, 'sounds.active');
  };

  return (
    <div className="pop" role="dialog" aria-label="Sonidos ambiente">
      <div className="pop-head">
        <span className="badge-ic" aria-hidden="true">
          <Icon name="music" />
        </span>
        <h2>Sonidos ambiente</h2>
        {playingList.length > 0 && (
          <button
            className="mini"
            title="Silenciar todo"
            aria-label="Silenciar todo"
            onClick={stopAll}
          >
            <Icon name="stop" />
          </button>
        )}
        <button
          className="x-btn"
          aria-label="Cerrar ventana de sonidos"
          onClick={onClose}
        >
          <Icon name="x" />
        </button>
      </div>

      <div className="pop-body">
        <div className="snd-list">
          {Object.entries(ambients).map(([id, item]) => {
            const isPlaying = audioX.isPlaying(id);
            const level = settings.sounds.levels[id] ?? 50;

            return (
              <div key={id} className={`snd ${isPlaying ? 'on' : ''}`}>
                <button
                  className="snd-toggle"
                  aria-pressed={isPlaying}
                  aria-label={`${isPlaying ? 'Pausar' : 'Reproducir'} ${item.name}`}
                  onClick={() => toggleSound(id)}
                >
                  <Icon name={isPlaying ? 'pause' : 'play'} />
                </button>
                <div className="snd-name">
                  {item.name}
                  <small>{item.desc}</small>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={level}
                  aria-label={`Volumen de ${item.name}`}
                  style={{ '--p': `${level}%` } as React.CSSProperties}
                  onChange={e => handleLevelChange(id, Number(e.target.value))}
                />
              </div>
            );
          })}
        </div>
      </div>

      <div className="pop-foot">
        <div className="master-row">
          <Icon name="volume" />
          <span className="snd-name grow">Volumen general</span>
          <input
            type="range"
            min="0"
            max="100"
            value={master}
            aria-label="Volumen general"
            style={{ '--p': `${master}%` } as React.CSSProperties}
            onChange={e => handleMasterChange(Number(e.target.value))}
          />
        </div>
      </div>
    </div>
  );
};
