import React, { useState, useEffect, useRef } from 'react';
import { Icon } from './Icons';
import type { Task, Subtask } from '../types';
import { uid } from '../lib/utils';
import { Store } from '../lib/store';
import { sync } from '../lib/sync';

interface TasksPopoverProps {
  open: boolean;
  onClose: () => void;
  tasks: Task[];
  onUpdateTasks: (tasks: Task[]) => void;
  onToast: (msg: string, type?: '' | 'err', action?: { label: string; fn: () => void }) => void;
  onConfirm: (title: string, text: string, okLabel: string, fn: () => void) => void;
}

export const TasksPopover: React.FC<TasksPopoverProps> = ({
  open,
  onClose,
  tasks,
  onUpdateTasks,
  onToast,
  onConfirm,
}) => {
  const [newTitle, setNewTitle] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');
  const [expandedId, setExpandedId] = useState<string | null>(null);
  const [subInput, setSubInput] = useState('');
  const [showDone, setShowDone] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!open) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [open, onClose]);

  if (!open) return null;

  const activeTasks = tasks
    .filter(t => !t.deleted && !t.done)
    .sort((a, b) => (a.order ?? 0) - (b.order ?? 0));

  const doneTasks = tasks
    .filter(t => !t.deleted && t.done)
    .sort((a, b) => b.updatedAt - a.updatedAt);

  const saveTasks = (nextTasks: Task[]) => {
    onUpdateTasks(nextTasks);
    Store.saveTaskItems(nextTasks);
    sync.touch();
  };

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    const title = newTitle.trim();
    if (!title) return;

    const maxOrder = tasks.reduce((m, t) => Math.max(m, t.order || 0), 0);
    const newTask: Task = {
      id: uid('t'),
      title,
      done: false,
      active: activeTasks.length === 0,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      order: maxOrder + 1,
      subtasks: [],
    };

    saveTasks([...tasks, newTask]);
    setNewTitle('');
  };

  const toggleDone = (id: string) => {
    const next = tasks.map(t => {
      if (t.id === id) {
        const done = !t.done;
        return {
          ...t,
          done,
          active: done ? false : t.active,
          updatedAt: Date.now(),
        };
      }
      return t;
    });
    saveTasks(next);
  };

  const toggleActive = (id: string) => {
    const next = tasks.map(t => ({
      ...t,
      active: t.id === id ? !t.active : false,
      updatedAt: Date.now(),
    }));
    saveTasks(next);
  };

  const deleteTask = (t: Task) => {
    const next = tasks.map(item =>
      item.id === t.id ? { ...item, deleted: true, updatedAt: Date.now() } : item
    );
    saveTasks(next);

    onToast(`Se eliminó “${t.title}”`, '', {
      label: 'Deshacer',
      fn: () => {
        const restored = Store.loadTaskItems().map(item =>
          item.id === t.id ? { ...item, deleted: false, updatedAt: Date.now() } : item
        );
        saveTasks(restored);
      },
    });
  };

  const startEdit = (t: Task) => {
    setEditingId(t.id);
    setEditTitle(t.title);
  };

  const commitEdit = (id: string) => {
    if (!editTitle.trim()) {
      setEditingId(null);
      return;
    }
    const next = tasks.map(t =>
      t.id === id ? { ...t, title: editTitle.trim(), updatedAt: Date.now() } : t
    );
    saveTasks(next);
    setEditingId(null);
  };

  const toggleSubtask = (taskId: string, subId: string) => {
    const next = tasks.map(t => {
      if (t.id === taskId) {
        const subs = (t.subtasks || []).map(s =>
          s.id === subId ? { ...s, done: !s.done } : s
        );
        return { ...t, subtasks: subs, updatedAt: Date.now() };
      }
      return t;
    });
    saveTasks(next);
  };

  const addSubtask = (taskId: string) => {
    const text = subInput.trim();
    if (!text) return;
    const next = tasks.map(t => {
      if (t.id === taskId) {
        const subs = [...(t.subtasks || []), { id: uid('sub'), title: text, done: false }];
        return { ...t, subtasks: subs, updatedAt: Date.now() };
      }
      return t;
    });
    saveTasks(next);
    setSubInput('');
  };

  const deleteSubtask = (taskId: string, subId: string) => {
    const next = tasks.map(t => {
      if (t.id === taskId) {
        const subs = (t.subtasks || []).filter(s => s.id !== subId);
        return { ...t, subtasks: subs, updatedAt: Date.now() };
      }
      return t;
    });
    saveTasks(next);
  };

  const setEstimate = (taskId: string, val: number) => {
    const next = tasks.map(t =>
      t.id === taskId
        ? { ...t, estimate: Math.max(0, val) || null, updatedAt: Date.now() }
        : t
    );
    saveTasks(next);
  };

  const clearDone = () => {
    onConfirm(
      '¿Borrar tareas completadas?',
      'Se eliminan permanentemente de la lista.',
      'Borrar',
      () => {
        const next = tasks.map(t =>
          t.done ? { ...t, deleted: true, updatedAt: Date.now() } : t
        );
        saveTasks(next);
      }
    );
  };

  return (
    <div className="pop" role="dialog" aria-label="Tareas">
      <div className="pop-head">
        <span className="badge-ic" aria-hidden="true">
          <Icon name="tasks" />
        </span>
        <h2>Tareas</h2>
        <button
          className="x-btn"
          aria-label="Cerrar panel de tareas"
          onClick={onClose}
        >
          <Icon name="x" />
        </button>
      </div>

      <div className="pop-body">
        {activeTasks.length === 0 ? (
          <div className="pop-empty">
            <strong>Sin tareas pendientes</strong>
            Agregá una abajo para ponerte a trabajar.
          </div>
        ) : (
          <ul className="task-list">
            {activeTasks.map(t => {
              const isEditing = editingId === t.id;
              const isExpanded = expandedId === t.id;
              const subDoneCount = (t.subtasks || []).filter(s => s.done).length;
              const subTotal = (t.subtasks || []).length;

              return (
                <li
                  key={t.id}
                  className={`task ${t.active ? 'active' : ''} ${t.done ? 'done' : ''}`}
                >
                  <div className="task-row">
                    <button
                      className="check"
                      aria-label={`Marcar como completada: ${t.title}`}
                      onClick={() => toggleDone(t.id)}
                    >
                      <Icon name="check" />
                    </button>

                    {isEditing ? (
                      <input
                        className="task-edit"
                        value={editTitle}
                        autoFocus
                        onChange={e => setEditTitle(e.target.value)}
                        onBlur={() => commitEdit(t.id)}
                        onKeyDown={e => {
                          if (e.key === 'Enter') commitEdit(t.id);
                          if (e.key === 'Escape') setEditingId(null);
                        }}
                      />
                    ) : (
                      <span
                        className="task-title"
                        onDoubleClick={() => startEdit(t)}
                      >
                        {t.title}
                      </span>
                    )}

                    {subTotal > 0 && (
                      <span className="task-meta">
                        {subDoneCount}/{subTotal}
                      </span>
                    )}

                    {t.estimate != null && t.estimate > 0 && (
                      <span className="task-meta" title="Pomodoros estimados">
                        {t.estimate}🍅
                      </span>
                    )}

                    <div className="task-actions">
                      <button
                        className={`mini ${t.active ? 'on' : ''}`}
                        title={t.active ? 'Tarea activa actual' : 'Marcar como tarea activa'}
                        aria-pressed={t.active}
                        onClick={() => toggleActive(t.id)}
                      >
                        <Icon name="target" />
                      </button>
                      <button
                        className="mini"
                        title={isExpanded ? 'Ocultar subtareas y detalles' : 'Subtareas y detalles'}
                        onClick={() => setExpandedId(isExpanded ? null : t.id)}
                      >
                        <Icon name="chev" style={{ transform: isExpanded ? 'rotate(180deg)' : 'none' }} />
                      </button>
                      <button
                        className="mini"
                        title="Eliminar tarea"
                        onClick={() => deleteTask(t)}
                      >
                        <Icon name="trash" />
                      </button>
                    </div>
                  </div>

                  {isExpanded && (
                    <div className="task-detail">
                      <div className="field-row">
                        <span>Estimación:</span>
                        <input
                          type="number"
                          min="0"
                          max="20"
                          value={t.estimate || 0}
                          style={{ width: '70px', minHeight: '30px', padding: '4px 8px' }}
                          onChange={e => setEstimate(t.id, Number(e.target.value))}
                        />
                        <span>sesiones de foco</span>
                      </div>

                      <ul className="sub-list">
                        {(t.subtasks || []).map(s => (
                          <li key={s.id} className={`sub ${s.done ? 'done' : ''}`}>
                            <button
                              className="check"
                              onClick={() => toggleSubtask(t.id, s.id)}
                            >
                              <Icon name="check" />
                            </button>
                            <span className="t">{s.title}</span>
                            <button
                              className="mini"
                              onClick={() => deleteSubtask(t.id, s.id)}
                            >
                              <Icon name="x" />
                            </button>
                          </li>
                        ))}
                      </ul>

                      <div className="inline-add">
                        <input
                          type="text"
                          placeholder="Agregar subtarea..."
                          value={subInput}
                          style={{ minHeight: '32px', padding: '4px 8px', flex: 1 }}
                          onChange={e => setSubInput(e.target.value)}
                          onKeyDown={e => {
                            if (e.key === 'Enter') {
                              e.preventDefault();
                              addSubtask(t.id);
                            }
                          }}
                        />
                        <button
                          className="btn"
                          style={{ minHeight: '32px', padding: '0 10px' }}
                          onClick={() => addSubtask(t.id)}
                        >
                          <Icon name="plus" />
                        </button>
                      </div>
                    </div>
                  )}
                </li>
              );
            })}
          </ul>
        )}

        {doneTasks.length > 0 && (
          <div>
            <div className="done-head">
              <button
                className="link-btn"
                onClick={() => setShowDone(!showDone)}
              >
                {showDone ? 'Ocultar completadas' : `Completadas (${doneTasks.length})`}
              </button>
              {showDone && (
                <button className="link-btn" onClick={clearDone}>
                  Borrar completadas
                </button>
              )}
            </div>

            {showDone && (
              <ul className="task-list">
                {doneTasks.map(t => (
                  <li key={t.id} className="task done">
                    <div className="task-row">
                      <button
                        className="check"
                        onClick={() => toggleDone(t.id)}
                      >
                        <Icon name="check" />
                      </button>
                      <span className="task-title">{t.title}</span>
                      <button
                        className="mini"
                        title="Eliminar tarea"
                        onClick={() => deleteTask(t)}
                      >
                        <Icon name="trash" />
                      </button>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
      </div>

      <div className="pop-foot">
        <form className="add-task" onSubmit={handleAddTask}>
          <input
            ref={inputRef}
            type="text"
            placeholder="¿En qué vas a trabajar?"
            value={newTitle}
            onChange={e => setNewTitle(e.target.value)}
          />
          <button type="submit" className="btn primary" disabled={!newTitle.trim()}>
            <Icon name="plus" />
          </button>
        </form>
      </div>
    </div>
  );
};
