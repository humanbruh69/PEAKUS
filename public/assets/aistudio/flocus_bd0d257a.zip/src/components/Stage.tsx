import React, { useState, useEffect } from 'react';
import { Icon, FlameIcon } from './Icons';
import type { Settings, ModeKey, TimerPhase, Task, TimerStatus } from '../types';
import { fmtClock, fmtDur, dayKey, hashStr } from '../lib/utils';
import { QUOTES } from '../lib/constants';

interface StageProps {
  settings: Settings;
  onUpdateSettings: (s: Settings, path?: string) => void;
  activeTask?: Task;
  onRenameTask?: (id: string, newTitle: string) => void;
  timerState: {
    status: TimerStatus;
    phase: TimerPhase;
    remainingMs: number;
    durationMs: number;
    cycle: number;
  };
  onToggleTimer: () => void;
  onResetTimer: () => void;
  onSkipTimer: () => void;
  onSetPhase: (p: TimerPhase) => void;
  onOpenTasks: () => void;
  onOpenSounds: () => void;
  onOpenNotes: () => void;
  onOpenSettings: () => void;
  tasksOpen: boolean;
  soundsOpen: boolean;
  notesOpen: boolean;
  settingsOpen: boolean;
  streakCount: number;
}

export const Stage: React.FC<StageProps> = ({
  settings,
  onUpdateSettings,
  activeTask,
  onRenameTask,
  timerState,
  onToggleTimer,
  onResetTimer,
  onSkipTimer,
  onSetPhase,
  onOpenTasks,
  onOpenSounds,
  onOpenNotes,
  onOpenSettings,
  tasksOpen,
  soundsOpen,
  notesOpen,
  settingsOpen,
  streakCount,
}) => {
  const [now, setNow] = useState(new Date());
  const [isEditingLabel, setIsEditingLabel] = useState(false);
  const [customLabel, setCustomLabel] = useState('');
  const [isFs, setIsFs] = useState(false);

  // Update clock every second
  useEffect(() => {
    const interval = setInterval(() => {
      setNow(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  // Sync fullscreen state
  useEffect(() => {
    const updateFs = () => {
      setIsFs(!!(document.fullscreenElement || (document as any).webkitFullscreenElement));
    };
    document.addEventListener('fullscreenchange', updateFs);
    document.addEventListener('webkitfullscreenchange', updateFs);
    return () => {
      document.removeEventListener('fullscreenchange', updateFs);
      document.removeEventListener('webkitfullscreenchange', updateFs);
    };
  }, []);

  const mode = settings.mode;
  const pomo = settings.timer.mode === 'pomodoro';

  // Format time parts
  const getTimeParts = (d: Date) => {
    const c = settings.clock;
    let h = d.getHours();
    const m = d.getMinutes();
    let ampm = '';
    if (c.format === '12') {
      ampm = h < 12 ? 'AM' : 'PM';
      h = h % 12 || 12;
    }
    const pad = (n: number) => String(n).padStart(2, '0');
    return {
      main: (c.format === '24' ? pad(h) : String(h)) + ':' + pad(m),
      secs: c.seconds ? pad(d.getSeconds()) : '',
      ampm,
    };
  };

  // Greeting
  const getGreeting = (d: Date) => {
    const s = settings;
    const name = s.name.trim();
    const n = name ? `, ${name}` : '';
    const h = d.getHours();
    const base =
      h < 5
        ? `Buenas noches${n}`
        : h < 13
        ? `Buen día${n}`
        : h < 20
        ? `Buenas tardes${n}`
        : `Buenas noches${n}`;
    if (!s.clock.dynamicGreetings) return base;
    const days = [
      'domingo',
      'lunes',
      'martes',
      'miércoles',
      'jueves',
      'viernes',
      'sábado',
    ];
    const day = days[d.getDay()];
    const opts = [
      `¡El ${day} está de tu lado${n}!`,
      `${base}`,
      `Hoy es un buen día para avanzar${n}`,
      h < 12
        ? `Que tengas una linda mañana${n}`
        : h < 20
        ? `Que rinda la tarde${n}`
        : `Última vuelta del día${n}`,
      `¿Arrancamos${n}?`,
      `Paso a paso se llega lejos${n}`,
      d.getDay() === 5
        ? `¡Ya es viernes${n}!`
        : d.getDay() === 1
        ? `Buen comienzo de semana${n}`
        : `¡Vamos con todo${n}!`,
    ];
    return opts[hashStr(dayKey(d.getTime()) + ':' + Math.floor(h / 3)) % opts.length];
  };

  // Date line
  const getDateLine = (d: Date) => {
    const s = d.toLocaleDateString('es-AR', {
      weekday: 'long',
      day: 'numeric',
      month: 'long',
    });
    return s.charAt(0).toUpperCase() + s.slice(1);
  };

  // Quote
  const getQuote = () => {
    const q = settings.quotes;
    if (q.useCustom && q.custom.trim()) return q.custom.trim();
    const d = now;
    let i: number;
    if (q.rotation === 'hourly') {
      i = hashStr(dayKey(d.getTime()) + d.getHours()) % QUOTES.length;
    } else {
      i = hashStr(dayKey(d.getTime())) % QUOTES.length;
    }
    return QUOTES[i];
  };

  // Activity Label
  const getActivityLabel = () => {
    if (timerState.phase !== 'focus') {
      return timerState.phase === 'short' ? 'Descanso corto' : 'Descanso largo';
    }
    return activeTask ? activeTask.title : settings.timer.label || 'Foco';
  };

  const handleLabelCommit = () => {
    setIsEditingLabel(false);
    const val = customLabel.trim();
    if (!val) return;
    if (activeTask && onRenameTask) {
      onRenameTask(activeTask.id, val);
    } else {
      const nextSettings = {
        ...settings,
        timer: { ...settings.timer, label: val },
      };
      onUpdateSettings(nextSettings, 'timer.label');
    }
  };

  const toggleFullscreen = async () => {
    try {
      if (isFs) {
        if (document.exitFullscreen) await document.exitFullscreen();
        else if ((document as any).webkitExitFullscreen)
          await (document as any).webkitExitFullscreen();
      } else {
        if (document.documentElement.requestFullscreen)
          await document.documentElement.requestFullscreen();
        else if ((document as any).webkitRequestFullscreen)
          await (document as any).webkitRequestFullscreen();
      }
    } catch {}
  };

  const tp = getTimeParts(now);
  const timeRemainingStr = fmtClock(timerState.remainingMs);
  const progressRatio =
    timerState.durationMs > 0
      ? Math.max(0, Math.min(1, 1 - timerState.remainingMs / timerState.durationMs))
      : 0;

  // Render flip or standard digits
  const renderDigits = (timeStr: string, flip = false) => {
    return (
      <>
        {Array.from(timeStr).map((ch, idx) => {
          if (ch === ':') {
            return (
              <span key={`col-${idx}`} className="c">
                :
              </span>
            );
          }
          return (
            <span key={`d-${idx}`} className={`d ${flip ? 'flipping' : ''}`}>
              <span>{ch}</span>
            </span>
          );
        })}
      </>
    );
  };

  return (
    <main className="stage" id="stage">
      {/* Top Left Logo */}
      {settings.appearance.showLogo && (
        <div className="logo fadeable" id="logo" aria-hidden="true">
          foco
        </div>
      )}

      {/* Top Right Quote */}
      {settings.quotes.show && mode !== 'ambient' && (
        <p className="quote fadeable" id="quote">
          {getQuote()}
        </p>
      )}

      {/* Ambient Clock in Ambient Mode */}
      {mode === 'ambient' && (
        <div className="ambient-clock fadeable" id="ambientClock">
          <span>
            {tp.main}
            {tp.ampm && <small> {tp.ampm}</small>}
          </span>
          {timerState.status !== 'idle' && (
            <small>
              · {timeRemainingStr}{' '}
              {timerState.phase === 'focus' ? 'foco' : 'descanso'}
              {timerState.status === 'paused' ? ' (pausa)' : ''}
            </small>
          )}
        </div>
      )}

      {/* Center Section */}
      <section
        className="center"
        id="center"
        data-mode={mode}
        aria-label="Reloj y temporizador"
      >
        {mode === 'home' && (
          <>
            {settings.clock.greetings && (
              <div id="labelWrap">
                <h1 className="label" id="label">
                  {getGreeting(now)}
                </h1>
              </div>
            )}

            <div id="clockWrap">
              <div
                className={`clock style-${settings.clock.style} ${
                  settings.clock.flip ? 'flip' : ''
                }`}
                aria-label={`Hora ${tp.main}`}
              >
                {renderDigits(tp.main, settings.clock.flip)}
                {tp.secs && (
                  <span className="secs">
                    {renderDigits(tp.secs, settings.clock.flip)}
                  </span>
                )}
                {tp.ampm && settings.clock.format === '12' && (
                  <span className="ampm">{tp.ampm}</span>
                )}
              </div>
            </div>

            {settings.clock.date && (
              <div className="date-line" id="dateLine">
                {getDateLine(now)}
              </div>
            )}
          </>
        )}

        {mode === 'focus' && (
          <>
            {/* Phase Switch (Pomodoro) */}
            {pomo && timerState.status !== 'running' && (
              <div
                className="phase-switch fadeable"
                id="phaseSwitch"
                role="group"
                aria-label="Etapa del temporizador"
              >
                <button
                  aria-pressed={timerState.phase === 'focus'}
                  onClick={() => onSetPhase('focus')}
                >
                  Foco
                </button>
                <button
                  aria-pressed={timerState.phase === 'short'}
                  onClick={() => onSetPhase('short')}
                >
                  Descanso corto
                </button>
                <button
                  aria-pressed={timerState.phase === 'long'}
                  onClick={() => onSetPhase('long')}
                >
                  Descanso largo
                </button>
              </div>
            )}

            {/* Activity Label */}
            <div id="labelWrap">
              {isEditingLabel ? (
                <input
                  className="label-input"
                  autoFocus
                  value={customLabel}
                  onChange={e => setCustomLabel(e.target.value)}
                  onBlur={handleLabelCommit}
                  onKeyDown={e => {
                    if (e.key === 'Enter') handleLabelCommit();
                    if (e.key === 'Escape') setIsEditingLabel(false);
                  }}
                />
              ) : timerState.phase === 'focus' ? (
                <button
                  className="label"
                  title="Editar el nombre de la actividad"
                  onClick={() => {
                    setCustomLabel(getActivityLabel());
                    setIsEditingLabel(true);
                  }}
                >
                  {getActivityLabel()}
                </button>
              ) : (
                <h1 className="label">{getActivityLabel()}</h1>
              )}
            </div>

            {/* Visual Timer Display */}
            <div id="clockWrap">
              {settings.timer.style === 'default' && (
                <div
                  className={`clock style-${settings.clock.style}`}
                  aria-label={`Tiempo restante: ${timeRemainingStr}`}
                >
                  {renderDigits(timeRemainingStr, false)}
                </div>
              )}

              {settings.timer.style === 'flip' && (
                <div
                  className={`clock style-${settings.clock.style} flip`}
                  aria-label={`Tiempo restante: ${timeRemainingStr}`}
                >
                  {renderDigits(timeRemainingStr, true)}
                </div>
              )}

              {settings.timer.style === 'bar' && (
                <div className="timer-visual">
                  <div className={`clock style-${settings.clock.style}`}>
                    {timeRemainingStr}
                  </div>
                  <div className="tv-bar">
                    <i style={{ width: `${progressRatio * 100}%` }} />
                  </div>
                </div>
              )}

              {settings.timer.style === 'gauge' && (
                <div className="timer-visual">
                  <svg className="tv-ring" viewBox="0 0 100 100">
                    <circle
                      className="trk"
                      cx="50"
                      cy="50"
                      r="42"
                      fill="none"
                      strokeWidth="8"
                    />
                    <circle
                      className="val"
                      cx="50"
                      cy="50"
                      r="42"
                      fill="none"
                      strokeWidth="8"
                      strokeDasharray={264}
                      strokeDashoffset={264 * (1 - progressRatio)}
                      transform="rotate(-90 50 50)"
                    />
                  </svg>
                  <div className={`clock style-${settings.clock.style} small`}>
                    {timeRemainingStr}
                  </div>
                </div>
              )}

              {settings.timer.style === 'dots' && (
                <div className="timer-visual">
                  <div className="tv-dots">
                    {Array.from({ length: 24 }, (_, i) => {
                      const on = i < Math.round(progressRatio * 24);
                      return <i key={i} className={on ? '' : 'off'} />;
                    })}
                  </div>
                  <div className={`clock style-${settings.clock.style} small`}>
                    {timeRemainingStr}
                  </div>
                </div>
              )}

              {settings.timer.style === 'pie' && (
                <div className="timer-visual">
                  <svg className="tv-pie" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="46" fill="rgba(255,255,255,.2)" />
                    <circle
                      cx="50"
                      cy="50"
                      r="23"
                      fill="none"
                      stroke="#fff"
                      strokeWidth="46"
                      strokeDasharray={145}
                      strokeDashoffset={145 * (1 - progressRatio)}
                      transform="rotate(-90 50 50)"
                    />
                  </svg>
                  <div className={`clock style-${settings.clock.style} small`}>
                    {timeRemainingStr}
                  </div>
                </div>
              )}
            </div>

            {/* Optional Progress Bar */}
            {settings.timer.progressBar && (
              <div className="timer-progress" aria-hidden="true">
                <i style={{ width: `${progressRatio * 100}%` }} />
              </div>
            )}

            {/* Controls */}
            <div className="controls fadeable" id="controls">
              <button
                className="ctl primary"
                id="btnToggle"
                aria-label={
                  timerState.status === 'running'
                    ? 'Pausar'
                    : timerState.status === 'paused'
                    ? 'Reanudar'
                    : 'Iniciar'
                }
                title={
                  (timerState.status === 'running'
                    ? 'Pausar'
                    : timerState.status === 'paused'
                    ? 'Reanudar'
                    : 'Iniciar') + ' (Espacio)'
                }
                onClick={onToggleTimer}
              >
                <Icon name={timerState.status === 'running' ? 'pause' : 'play'} />
              </button>

              <button
                className="ctl"
                id="btnReset"
                aria-label="Reiniciar la etapa"
                title="Reiniciar (R)"
                onClick={onResetTimer}
              >
                <Icon name="reset" />
              </button>

              <button
                className="ctl"
                id="btnSkip"
                aria-label="Siguiente etapa"
                title={
                  timerState.phase === 'focus'
                    ? pomo
                      ? 'Pasar al descanso (N)'
                      : 'Terminar (N)'
                    : 'Pasar al foco (N)'
                }
                onClick={onSkipTimer}
              >
                <Icon name="skip" />
              </button>
            </div>

            {/* Tallies */}
            {pomo && settings.timer.tallies !== 'none' && (
              <div className="tallies fadeable" id="tallies" role="img">
                {settings.timer.tallies === 'dots' ? (
                  Array.from({ length: settings.timer.cycles }, (_, i) => (
                    <i
                      key={i}
                      className={
                        i < Math.min(timerState.cycle, settings.timer.cycles)
                          ? 'on'
                          : ''
                      }
                    />
                  ))
                ) : (
                  <span>
                    {Math.min(timerState.cycle, settings.timer.cycles)}/
                    {settings.timer.cycles} sesiones
                  </span>
                )}
              </div>
            )}
          </>
        )}
      </section>

      {/* Corner Left Navigation */}
      <nav className="corner left fadeable" aria-label="Herramientas">
        <button
          className={`ib has-tip ${tasksOpen ? 'active' : ''}`}
          id="btnTasks"
          aria-label="Tareas"
          aria-expanded={tasksOpen}
          onClick={onOpenTasks}
        >
          <Icon name="tasks" />
          <span className="tip">Tareas (T)</span>
        </button>

        <button
          className={`ib has-tip ${soundsOpen ? 'active' : ''}`}
          id="btnSounds"
          aria-label="Sonidos ambiente"
          aria-expanded={soundsOpen}
          onClick={onOpenSounds}
        >
          <Icon name="music" />
          <span className="tip">Sonidos (M)</span>
        </button>

        <button
          className={`ib has-tip ${notesOpen ? 'active' : ''}`}
          id="btnNotes"
          aria-label="Notas rápidas"
          aria-expanded={notesOpen}
          onClick={onOpenNotes}
        >
          <Icon name="pencil" />
          <span className="tip">Notas</span>
        </button>
      </nav>

      {/* Corner Right Navigation */}
      <nav className="corner right fadeable" aria-label="Modos y ajustes">
        {settings.timer.showStreak && (
          <button className="streak has-tip" id="streak">
            <span id="streakIc">
              <FlameIcon />
            </span>
            <span id="streakN">{streakCount}</span>
            <span className="tip">
              Racha: {streakCount} {streakCount === 1 ? 'día' : 'días'} (meta{' '}
              {settings.timer.streakGoal} min/día)
            </span>
          </button>
        )}

        <div className="modes" role="group" aria-label="Modo">
          <button
            className="has-tip"
            data-mode="ambient"
            aria-label="Modo Ambient"
            aria-pressed={mode === 'ambient'}
            onClick={() => {
              const next = { ...settings, mode: 'ambient' as ModeKey };
              onUpdateSettings(next, 'mode');
            }}
          >
            <Icon name="cloud" />
            <span className="tip">Ambient (3)</span>
          </button>

          <button
            className="has-tip"
            data-mode="home"
            aria-label="Modo Home"
            aria-pressed={mode === 'home'}
            onClick={() => {
              const next = { ...settings, mode: 'home' as ModeKey };
              onUpdateSettings(next, 'mode');
            }}
          >
            <Icon name="home" />
            <span className="tip">Home (1)</span>
          </button>

          <button
            className="has-tip"
            data-mode="focus"
            aria-label="Modo Focus"
            aria-pressed={mode === 'focus'}
            onClick={() => {
              const next = { ...settings, mode: 'focus' as ModeKey };
              onUpdateSettings(next, 'mode');
            }}
          >
            <Icon name="bulb" />
            <span className="tip">Focus (2)</span>
          </button>
        </div>

        <button
          className={`ib has-tip ${settingsOpen ? 'active' : ''}`}
          id="btnSettings"
          aria-label="Ajustes"
          aria-expanded={settingsOpen}
          onClick={onOpenSettings}
        >
          <Icon name="gear" />
          <span className="tip">Ajustes (,)</span>
        </button>

        <button
          className="ib has-tip"
          id="btnFs"
          aria-label={isFs ? 'Salir de pantalla completa' : 'Pantalla completa'}
          onClick={toggleFullscreen}
        >
          <Icon name={isFs ? 'compress' : 'expand'} />
          <span className="tip">
            {isFs ? 'Salir de pantalla completa' : 'Pantalla completa'} (F)
          </span>
        </button>
      </nav>
    </main>
  );
};
