import React, { useState, useEffect, useRef, useCallback } from 'react';
import type {
  Settings,
  ModeKey,
  Task,
  Session,
  TimerState,
  TimerPhase,
  TimerStatus,
} from './types';
import { Store } from './lib/store';
import { audioX } from './lib/audio';
import { sync } from './lib/sync';
import { hexToRgb, fmtClock, fmtDur, uid, dayKey, startOfDay, addDays } from './lib/utils';

import { Background } from './components/Background';
import { Stage } from './components/Stage';
import { TasksPopover } from './components/TasksPopover';
import { SoundsPopover } from './components/SoundsPopover';
import { NotesPopover } from './components/NotesPopover';
import { SettingsModal } from './components/SettingsModal';
import { ConfirmModal, type ConfirmState } from './components/ConfirmModal';
import { ToastList, type ToastItem } from './components/ToastList';

export const App: React.FC = () => {
  const [settings, setSettings] = useState<Settings>(() => Store.loadSettings());
  const [tasks, setTasks] = useState<Task[]>(() => Store.loadTaskItems());
  const [sessions, setSessions] = useState<Session[]>(() => Store.loadSessions());
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [confirmModal, setConfirmModal] = useState<ConfirmState | null>(null);

  // Popovers & Modal State
  const [tasksOpen, setTasksOpen] = useState(false);
  const [soundsOpen, setSoundsOpen] = useState(false);
  const [notesOpen, setNotesOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  // Active Task
  const activeTask = tasks.find(t => t.active && !t.deleted && !t.done);

  // Calculate duration for a phase
  const getPhaseDuration = useCallback(
    (phase: TimerPhase, currentSettings: Settings) => {
      const t = currentSettings.timer;
      if (t.mode === 'countdown') {
        return t.countdown * 60000;
      }
      if (phase === 'focus') {
        if (t.etaMode && activeTask && activeTask.estimate) {
          const focusedMs = sessions
            .filter(s => s.taskId === activeTask.id && s.kind === 'focus')
            .reduce((sum, s) => sum + s.ms, 0);
          const rem = activeTask.estimate * 60000 - focusedMs;
          if (rem > 0) return rem;
        }
        return t.focus * 60000;
      }
      if (phase === 'short') return t.short * 60000;
      return t.long * 60000;
    },
    [activeTask, sessions]
  );

  // Timer State
  const [timerState, setTimerState] = useState<TimerState>(() => {
    const saved = Store.loadTimer();
    const phase: TimerPhase = saved?.phase || 'focus';
    const status: TimerStatus = saved?.status || 'idle';
    const duration = getPhaseDuration(phase, settings);
    const rem = saved && typeof saved.remainingMs === 'number' && saved.remainingMs > 0 ? saved.remainingMs : duration;

    return {
      status,
      phase,
      remainingMs: rem,
      durationMs: duration,
      cycle: saved?.cycle || 0,
      startedAt: saved?.startedAt || null,
      sessionStartedAt: saved?.sessionStartedAt || null,
      interrupted: !!saved?.interrupted,
    };
  });

  const timerRef = useRef(timerState);
  timerRef.current = timerState;
  const settingsRef = useRef(settings);
  settingsRef.current = settings;

  // Add Toast helper
  const addToast = useCallback(
    (msg: string, type: 'err' | '' = '', action?: { label: string; fn: () => void }) => {
      const id = uid('toast');
      setToasts(prev => [...prev.slice(-2), { id, msg, type, action }]);
      setTimeout(() => {
        setToasts(prev => prev.filter(t => t.id !== id));
      }, type === 'err' ? 6500 : 4500);
    },
    []
  );

  // Ask Confirm helper
  const askConfirm = useCallback(
    (
      title: string,
      text: string,
      okLabel: string,
      fn: () => void,
      danger = true
    ) => {
      setConfirmModal({
        open: true,
        title,
        text,
        okText: okLabel,
        danger,
        onConfirm: () => {
          setConfirmModal(null);
          fn();
        },
        onCancel: () => setConfirmModal(null),
      });
    },
    []
  );

  // Apply Appearance CSS Variables
  useEffect(() => {
    const s = settings;
    const r = document.documentElement.style;
    const [R, G, B] = hexToRgb(s.appearance.accent);
    r.setProperty('--accent', s.appearance.accent);
    r.setProperty('--accent-soft', `rgba(${R},${G},${B},.24)`);
    const mix = (v: number) => Math.round(v + (255 - v) * 0.45);
    r.setProperty('--accent-text', `rgb(${mix(R)},${mix(G)},${mix(B)})`);
    r.setProperty('--clock-color', s.clock.color);
    r.setProperty('--clock-scale', String(s.clock.size / 100));
  }, [settings.appearance.accent, settings.clock.color, settings.clock.size]);

  // Audio master update
  useEffect(() => {
    audioX.setMaster(settings.sounds.master);
  }, [settings.sounds.master]);

  // Sync callbacks setup
  useEffect(() => {
    sync.setCallbacks({
      getSettings: () => settingsRef.current,
      onRemoteSettings: nextSettings => setSettings(nextSettings),
      onRemoteTasks: nextTasks => {
        setTasks(nextTasks);
        Store.saveTaskItems(nextTasks);
      },
      onRemoteHistory: nextSessions => {
        setSessions(nextSessions);
        Store.saveSessions(nextSessions);
      },
      onRemoteNotes: () => {},
    });
    sync.start();
  }, []);

  // Update Document Title
  useEffect(() => {
    if (timerState.status === 'running') {
      const rem = fmtClock(timerState.remainingMs);
      const act = activeTask ? activeTask.title : settings.timer.label || 'Foco';
      document.title = `${rem} · ${act} — foco`;
    } else {
      document.title = 'foco';
    }
  }, [timerState.status, timerState.remainingMs, activeTask, settings.timer.label]);

  // Calculate Streak
  const streakCount = React.useMemo(() => {
    const goalMs = settings.timer.streakGoal * 60000;
    const dayMap = new Map<string, number>();
    sessions
      .filter(s => s.kind === 'focus')
      .forEach(s => {
        const k = dayKey(s.start);
        dayMap.set(k, (dayMap.get(k) || 0) + s.ms);
      });

    let current = 0;
    let checkD = startOfDay(Date.now());
    if ((dayMap.get(dayKey(checkD)) || 0) >= goalMs) {
      current++;
      checkD = addDays(checkD, -1);
    } else {
      checkD = addDays(checkD, -1);
    }
    while ((dayMap.get(dayKey(checkD)) || 0) >= goalMs) {
      current++;
      checkD = addDays(checkD, -1);
    }
    return current;
  }, [sessions, settings.timer.streakGoal]);

  // Segment Completion Handler
  const handleSegmentEnd = useCallback(
    (prevPhase: TimerPhase, durationMs: number) => {
      const currentS = settingsRef.current;
      const t = currentS.timer;
      const now = Date.now();

      // Record completed session in history
      const newSession: Session = {
        id: uid('s'),
        kind: prevPhase === 'focus' ? 'focus' : 'break',
        phase: prevPhase,
        start: now - durationMs,
        end: now,
        ms: durationMs,
        completed: true,
        taskId: prevPhase === 'focus' && activeTask ? activeTask.id : null,
        title: prevPhase === 'focus' ? (activeTask ? activeTask.title : t.label || 'Foco') : '',
      };

      const nextSessions = [newSession, ...sessions];
      setSessions(nextSessions);
      Store.saveSessions(nextSessions);
      sync.touch();

      // Play alert sound
      audioX.playAlert(t.sound, t.volume);

      // Determine next phase and auto-start
      let nextPhase: TimerPhase = 'focus';
      let autoStart = false;
      let nextCycle = timerRef.current.cycle;

      if (t.mode === 'countdown') {
        nextPhase = 'focus';
        autoStart = t.autoBreak;
      } else {
        if (prevPhase === 'focus') {
          nextCycle = timerRef.current.cycle + 1;
          nextPhase = nextCycle % t.cycles === 0 ? 'long' : 'short';
          autoStart = t.autoBreak;
        } else {
          nextPhase = 'focus';
          autoStart = t.autoFocus;
        }
      }

      const nextDuration = getPhaseDuration(nextPhase, currentS);

      const nextState: TimerState = {
        status: autoStart ? 'running' : 'idle',
        phase: nextPhase,
        remainingMs: nextDuration,
        durationMs: nextDuration,
        cycle: nextCycle,
        startedAt: autoStart ? now : null,
        sessionStartedAt: autoStart ? now : null,
        interrupted: false,
      };

      setTimerState(nextState);
      Store.saveTimer(nextState);

      const nextName =
        nextPhase === 'focus'
          ? 'foco'
          : nextPhase === 'short'
          ? 'descanso corto'
          : 'descanso largo';

      const toastMsg =
        prevPhase === 'focus'
          ? `¡Sesión completa! Sumaste ${fmtDur(durationMs)} de foco. ${
              autoStart ? `Arrancó el ${nextName}.` : `Cuando quieras, iniciá el ${nextName}.`
            }`
          : `Terminó el descanso. ${
              autoStart ? 'Arrancó una nueva sesión de foco.' : '¿Seguimos?'
            }`;

      addToast(toastMsg);

      if (
        t.notify &&
        'Notification' in window &&
        Notification.permission === 'granted' &&
        (document.hidden || !document.hasFocus())
      ) {
        try {
          new Notification(
            prevPhase === 'focus' ? '¡Sesión completa!' : 'Terminó el descanso',
            { body: toastMsg, tag: 'foco-timer' }
          );
        } catch {}
      }
    },
    [sessions, activeTask, getPhaseDuration, addToast]
  );

  // Timer Tick Engine
  useEffect(() => {
    if (timerState.status !== 'running') return;

    let lastTick = performance.now();
    const interval = setInterval(() => {
      const now = performance.now();
      const delta = now - lastTick;
      lastTick = now;

      setTimerState(prev => {
        if (prev.status !== 'running') return prev;
        const remaining = prev.remainingMs - delta;
        if (remaining <= 0) {
          handleSegmentEnd(prev.phase, prev.durationMs);
          return {
            ...prev,
            status: 'idle',
            remainingMs: 0,
          };
        }
        return {
          ...prev,
          remainingMs: remaining,
        };
      });
    }, 200);

    return () => clearInterval(interval);
  }, [timerState.status, handleSegmentEnd]);

  // Controls Handlers
  const handleToggleTimer = () => {
    audioX.ensure();
    const cur = timerRef.current;
    if (cur.status === 'running') {
      const next: TimerState = {
        ...cur,
        status: 'paused',
      };
      setTimerState(next);
      Store.saveTimer(next);
    } else {
      const now = Date.now();
      const next: TimerState = {
        ...cur,
        status: 'running',
        startedAt: cur.startedAt || now,
        sessionStartedAt: cur.sessionStartedAt || now,
      };
      setTimerState(next);
      Store.saveTimer(next);
    }
  };

  const handleResetTimer = () => {
    const cur = timerRef.current;
    const duration = getPhaseDuration(cur.phase, settings);
    const next: TimerState = {
      ...cur,
      status: 'idle',
      remainingMs: duration,
      durationMs: duration,
      startedAt: null,
      sessionStartedAt: null,
    };
    setTimerState(next);
    Store.saveTimer(next);
  };

  const handleSkipTimer = () => {
    const cur = timerRef.current;
    const t = settings.timer;

    // If session was running and >= 1 minute, record as interrupted
    if (cur.status === 'running' && cur.sessionStartedAt) {
      const elapsed = cur.durationMs - cur.remainingMs;
      if (elapsed >= 60000) {
        const interruptedSession: Session = {
          id: uid('s'),
          kind: cur.phase === 'focus' ? 'focus' : 'break',
          phase: cur.phase,
          start: cur.sessionStartedAt,
          end: Date.now(),
          ms: elapsed,
          completed: false,
          taskId: cur.phase === 'focus' && activeTask ? activeTask.id : null,
          title: cur.phase === 'focus' ? (activeTask ? activeTask.title : t.label || 'Foco') : '',
        };
        const nextSessions = [interruptedSession, ...sessions];
        setSessions(nextSessions);
        Store.saveSessions(nextSessions);
        sync.touch();
      }
    }

    let nextPhase: TimerPhase = 'focus';
    let nextCycle = cur.cycle;

    if (t.mode === 'pomodoro') {
      if (cur.phase === 'focus') {
        nextCycle = cur.cycle + 1;
        nextPhase = nextCycle % t.cycles === 0 ? 'long' : 'short';
      } else {
        nextPhase = 'focus';
      }
    }

    const duration = getPhaseDuration(nextPhase, settings);
    const next: TimerState = {
      status: 'idle',
      phase: nextPhase,
      remainingMs: duration,
      durationMs: duration,
      cycle: nextCycle,
      startedAt: null,
      sessionStartedAt: null,
      interrupted: false,
    };

    setTimerState(next);
    Store.saveTimer(next);
  };

  const handleSetPhase = (phase: TimerPhase) => {
    const duration = getPhaseDuration(phase, settings);
    const next: TimerState = {
      ...timerRef.current,
      status: 'idle',
      phase,
      remainingMs: duration,
      durationMs: duration,
      startedAt: null,
      sessionStartedAt: null,
    };
    setTimerState(next);
    Store.saveTimer(next);
  };

  // Zen Mode (Auto-hide controls)
  useEffect(() => {
    if (!settings.appearance.autoHide) {
      document.body.classList.remove('zen-hidden');
      return;
    }

    let zenTimer: any = null;
    const isEligible = () => {
      if (tasksOpen || soundsOpen || notesOpen || settingsOpen || confirmModal?.open) {
        return false;
      }
      return settings.mode === 'ambient' || timerRef.current.status === 'running';
    };

    const wake = () => {
      document.body.classList.remove('zen-hidden');
      clearTimeout(zenTimer);
      zenTimer = setTimeout(() => {
        if (isEligible()) {
          document.body.classList.add('zen-hidden');
        }
      }, settings.appearance.autoHideDelay * 1000);
    };

    const events = ['pointermove', 'pointerdown', 'keydown', 'wheel', 'touchstart'];
    events.forEach(ev => window.addEventListener(ev, wake, { passive: true }));
    wake();

    return () => {
      clearTimeout(zenTimer);
      document.body.classList.remove('zen-hidden');
      events.forEach(ev => window.removeEventListener(ev, wake));
    };
  }, [
    settings.appearance.autoHide,
    settings.appearance.autoHideDelay,
    settings.mode,
    timerState.status,
    tasksOpen,
    soundsOpen,
    notesOpen,
    settingsOpen,
    confirmModal,
  ]);

  // Global Keyboard Shortcuts
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (confirmModal?.open) return;
        if (settingsOpen) {
          e.preventDefault();
          setSettingsOpen(false);
          return;
        }
        if (tasksOpen || soundsOpen || notesOpen) {
          e.preventDefault();
          setTasksOpen(false);
          setSoundsOpen(false);
          setNotesOpen(false);
          return;
        }
        return;
      }

      if (e.ctrlKey || e.metaKey || e.altKey) return;
      const tag = (e.target as HTMLElement)?.tagName?.toLowerCase() || '';
      if (['input', 'textarea', 'select'].includes(tag) || (e.target as HTMLElement)?.isContentEditable) {
        return;
      }
      if (settingsOpen || confirmModal?.open) return;

      const k = e.key.toLowerCase();
      const onBtn = tag === 'button' || tag === 'a';

      if (k === ' ' && !onBtn) {
        e.preventDefault();
        handleToggleTimer();
      } else if (k === 'r') {
        handleResetTimer();
      } else if (k === 'n' || k === 's') {
        handleSkipTimer();
      } else if (k === 't') {
        setTasksOpen(prev => !prev);
        setSoundsOpen(false);
        setNotesOpen(false);
      } else if (k === 'm') {
        setSoundsOpen(prev => !prev);
        setTasksOpen(false);
        setNotesOpen(false);
      } else if (k === '1') {
        const next = { ...settings, mode: 'home' as ModeKey };
        setSettings(next);
        Store.saveSettings(next);
      } else if (k === '2') {
        const next = { ...settings, mode: 'focus' as ModeKey };
        setSettings(next);
        Store.saveSettings(next);
      } else if (k === '3') {
        const next = { ...settings, mode: 'ambient' as ModeKey };
        setSettings(next);
        Store.saveSettings(next);
      } else if (k === ',') {
        setSettingsOpen(prev => !prev);
        setTasksOpen(false);
        setSoundsOpen(false);
        setNotesOpen(false);
      }
    };

    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [settingsOpen, tasksOpen, soundsOpen, notesOpen, confirmModal, settings]);

  const handleUpdateSettings = (nextSettings: Settings, path = '') => {
    setSettings(nextSettings);
    Store.saveSettings(nextSettings);
    if (path !== 'mode') {
      sync.touch();
    }
  };

  const handleRenameTask = (id: string, newTitle: string) => {
    const next = tasks.map(t =>
      t.id === id ? { ...t, title: newTitle, updatedAt: Date.now() } : t
    );
    setTasks(next);
    Store.saveTaskItems(next);
    sync.touch();
  };

  return (
    <>
      {/* Background Canvas & Layers */}
      <Background
        settings={settings}
        onUpdateModeBg={(m: ModeKey, newBg: any) => {
          const next = {
            ...settings,
            modes: {
              ...settings.modes,
              [m]: { ...settings.modes[m], bg: newBg },
            },
          };
          handleUpdateSettings(next, `modes.${m}.bg`);
        }}
        onErrorToast={msg => addToast(msg, 'err')}
      />

      {/* Main Stage UI */}
      <Stage
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        activeTask={activeTask}
        onRenameTask={handleRenameTask}
        timerState={timerState}
        onToggleTimer={handleToggleTimer}
        onResetTimer={handleResetTimer}
        onSkipTimer={handleSkipTimer}
        onSetPhase={handleSetPhase}
        onOpenTasks={() => {
          setTasksOpen(prev => !prev);
          setSoundsOpen(false);
          setNotesOpen(false);
        }}
        onOpenSounds={() => {
          setSoundsOpen(prev => !prev);
          setTasksOpen(false);
          setNotesOpen(false);
        }}
        onOpenNotes={() => {
          setNotesOpen(prev => !prev);
          setTasksOpen(false);
          setSoundsOpen(false);
        }}
        onOpenSettings={() => {
          setSettingsOpen(true);
          setTasksOpen(false);
          setSoundsOpen(false);
          setNotesOpen(false);
        }}
        tasksOpen={tasksOpen}
        soundsOpen={soundsOpen}
        notesOpen={notesOpen}
        settingsOpen={settingsOpen}
        streakCount={streakCount}
      />

      {/* Tasks Popover */}
      <TasksPopover
        open={tasksOpen}
        onClose={() => setTasksOpen(false)}
        tasks={tasks}
        onUpdateTasks={next => {
          setTasks(next);
          Store.saveTaskItems(next);
        }}
        onToast={addToast}
        onConfirm={askConfirm}
      />

      {/* Sounds Popover */}
      <SoundsPopover
        open={soundsOpen}
        onClose={() => setSoundsOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
      />

      {/* Notes Popover */}
      <NotesPopover
        open={notesOpen}
        onClose={() => setNotesOpen(false)}
      />

      {/* Settings Modal */}
      <SettingsModal
        open={settingsOpen}
        onClose={() => setSettingsOpen(false)}
        settings={settings}
        onUpdateSettings={handleUpdateSettings}
        tasks={tasks}
        onUpdateTasks={next => {
          setTasks(next);
          Store.saveTaskItems(next);
        }}
        sessions={sessions}
        onUpdateSessions={next => {
          setSessions(next);
          Store.saveSessions(next);
        }}
        onToast={addToast}
        onConfirm={askConfirm}
      />

      {/* Confirm Modal */}
      <ConfirmModal state={confirmModal} />

      {/* Toasts */}
      <ToastList
        toasts={toasts}
        onRemove={id => setToasts(prev => prev.filter(t => t.id !== id))}
      />
    </>
  );
};
